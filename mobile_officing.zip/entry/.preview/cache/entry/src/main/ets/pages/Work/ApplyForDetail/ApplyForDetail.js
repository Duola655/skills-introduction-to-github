import router from '@ohos:router';
import { NavBar } from '@bundle:top.huangjiangjun.mobile_officing/entry/ets/components/NavBar';
import { applyForStatus, applyForStatusColor } from '@bundle:top.huangjiangjun.mobile_officing/entry/ets/utils/ApplyForUtil';
class ApplyForDetail extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1) {
        super(parent, __localStorage, elmtId);
        this.__process = new ObservedPropertyObjectPU({}, this, "process");
        this.setInitiallyProvidedValue(params);
    }
    setInitiallyProvidedValue(params) {
        if (params.process !== undefined) {
            this.process = params.process;
        }
    }
    updateStateVars(params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__process.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__process.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    get process() {
        return this.__process.get();
    }
    set process(newValue) {
        this.__process.set(newValue);
    }
    aboutToAppear() {
        this.process = router.getParams();
    }
    buildHeader(parent = null) {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create();
            Row.debugLine("pages/Work/ApplyForDetail/ApplyForDetail.ets(16:5)");
            Row.height(80);
            Row.justifyContent(FlexAlign.SpaceBetween);
            Row.padding({ left: 15, right: 15 });
            Row.backgroundColor(Color.White);
            Row.width('100%');
            Row.borderRadius(8);
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            // 左边
            Row.create();
            Row.debugLine("pages/Work/ApplyForDetail/ApplyForDetail.ets(18:7)");
            if (!isInitialRender) {
                // 左边
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create();
            Text.debugLine("pages/Work/ApplyForDetail/ApplyForDetail.ets(19:9)");
            Text.width(20);
            Text.height(20);
            Text.borderRadius(10);
            Text.backgroundColor('#4749a1');
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create(`${this.process.initiator}${this.process.type}`);
            Text.debugLine("pages/Work/ApplyForDetail/ApplyForDetail.ets(25:9)");
            Text.fontSize(18);
            Text.fontColor('#101010');
            Text.fontWeight(FontWeight.Bold);
            Text.margin({ left: 10 });
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        // 左边
        Row.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            // 右边
            Text.create(applyForStatus(this.process.approve_status));
            Text.debugLine("pages/Work/ApplyForDetail/ApplyForDetail.ets(33:7)");
            // 右边
            Text.fontColor(applyForStatusColor(this.process.approve_status));
            if (!isInitialRender) {
                // 右边
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        // 右边
        Text.pop();
        Row.pop();
    }
    buildContent(parent = null) {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create();
            Column.debugLine("pages/Work/ApplyForDetail/ApplyForDetail.ets(45:5)");
            Column.padding(15);
            Column.width('100%');
            Column.borderRadius(8);
            Column.margin({ top: 15 });
            Column.backgroundColor(Color.White);
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create();
            Row.debugLine("pages/Work/ApplyForDetail/ApplyForDetail.ets(46:7)");
            Row.height(40);
            Row.width('100%');
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create(`审批编号：${this.process.approve_number}`);
            Text.debugLine("pages/Work/ApplyForDetail/ApplyForDetail.ets(47:9)");
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        Row.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create();
            Row.debugLine("pages/Work/ApplyForDetail/ApplyForDetail.ets(52:7)");
            Row.height(40);
            Row.width('100%');
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create(`所在部门：${this.process.department}`);
            Text.debugLine("pages/Work/ApplyForDetail/ApplyForDetail.ets(53:9)");
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        Row.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create();
            Row.debugLine("pages/Work/ApplyForDetail/ApplyForDetail.ets(58:7)");
            Row.height(40);
            Row.width('100%');
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create(`请假类型：${this.process.type}`);
            Text.debugLine("pages/Work/ApplyForDetail/ApplyForDetail.ets(59:9)");
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        Row.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create();
            Row.debugLine("pages/Work/ApplyForDetail/ApplyForDetail.ets(64:7)");
            Row.height(40);
            Row.width('100%');
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            If.create();
            if (this.process.type_id == "1") {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation((elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        Text.create(`开始时间：${this.process.begin_date} ${this.process.begin_time}`);
                        Text.debugLine("pages/Work/ApplyForDetail/ApplyForDetail.ets(66:11)");
                        if (!isInitialRender) {
                            Text.pop();
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    });
                    Text.pop();
                });
            }
            else if (this.process.type_id == "2") {
                this.ifElseBranchUpdateFunction(1, () => {
                    this.observeComponentCreation((elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        Text.create(`开始时间：${this.process.begin_time}`);
                        Text.debugLine("pages/Work/ApplyForDetail/ApplyForDetail.ets(68:11)");
                        if (!isInitialRender) {
                            Text.pop();
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    });
                    Text.pop();
                });
            }
            if (!isInitialRender) {
                If.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        If.pop();
        Row.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create();
            Row.debugLine("pages/Work/ApplyForDetail/ApplyForDetail.ets(74:7)");
            Row.height(40);
            Row.width('100%');
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            If.create();
            if (this.process.type_id == "1") {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation((elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        Text.create(`结束时间：${this.process.end_date} ${this.process.end_time}`);
                        Text.debugLine("pages/Work/ApplyForDetail/ApplyForDetail.ets(76:11)");
                        if (!isInitialRender) {
                            Text.pop();
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    });
                    Text.pop();
                });
            }
            else if (this.process.type_id == "2") {
                this.ifElseBranchUpdateFunction(1, () => {
                    this.observeComponentCreation((elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        Text.create(`结束时间：${this.process.end_time}`);
                        Text.debugLine("pages/Work/ApplyForDetail/ApplyForDetail.ets(78:11)");
                        if (!isInitialRender) {
                            Text.pop();
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    });
                    Text.pop();
                });
            }
            if (!isInitialRender) {
                If.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        If.pop();
        Row.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create();
            Row.debugLine("pages/Work/ApplyForDetail/ApplyForDetail.ets(85:7)");
            Row.height(40);
            Row.width('100%');
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            If.create();
            if (this.process.type_id == "1") {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation((elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        Text.create(`请假天数：${this.process.days}天`);
                        Text.debugLine("pages/Work/ApplyForDetail/ApplyForDetail.ets(87:11)");
                        if (!isInitialRender) {
                            Text.pop();
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    });
                    Text.pop();
                });
            }
            else if (this.process.type_id == "2") {
                this.ifElseBranchUpdateFunction(1, () => {
                    this.observeComponentCreation((elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        Text.create(`加班时长：${this.process.hours}小时`);
                        Text.debugLine("pages/Work/ApplyForDetail/ApplyForDetail.ets(90:11)");
                        if (!isInitialRender) {
                            Text.pop();
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    });
                    Text.pop();
                });
            }
            if (!isInitialRender) {
                If.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        If.pop();
        Row.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create();
            Row.debugLine("pages/Work/ApplyForDetail/ApplyForDetail.ets(97:7)");
            Row.alignItems(VerticalAlign.Top);
            Row.margin({ top: 10 });
            Row.width('100%');
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            If.create();
            if (this.process.type_id == "1") {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation((elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        Text.create("请假事由：");
                        Text.debugLine("pages/Work/ApplyForDetail/ApplyForDetail.ets(99:11)");
                        if (!isInitialRender) {
                            Text.pop();
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    });
                    Text.pop();
                });
            }
            else if (this.process.type_id == "2") {
                this.ifElseBranchUpdateFunction(1, () => {
                    this.observeComponentCreation((elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        Text.create("加班原因：");
                        Text.debugLine("pages/Work/ApplyForDetail/ApplyForDetail.ets(101:11)");
                        if (!isInitialRender) {
                            Text.pop();
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    });
                    Text.pop();
                });
            }
            if (!isInitialRender) {
                If.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        If.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create(this.process.reason);
            Text.debugLine("pages/Work/ApplyForDetail/ApplyForDetail.ets(104:9)");
            Text.layoutWeight(1);
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        Row.pop();
        Column.pop();
    }
    buildProcess(parent = null) {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create();
            Row.debugLine("pages/Work/ApplyForDetail/ApplyForDetail.ets(119:5)");
            Row.padding(15);
            Row.width('100%');
            Row.borderRadius(8);
            Row.margin({ top: 15 });
            Row.backgroundColor(Color.White);
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Image.create({ "id": 0, "type": 30000, params: ["process/process1.png"], "bundleName": "top.huangjiangjun.mobile_officing", "moduleName": "entry" });
            Image.debugLine("pages/Work/ApplyForDetail/ApplyForDetail.ets(120:7)");
            Image.width(30);
            Image.height(230);
            Image.objectFit(ImageFit.Cover);
            if (!isInitialRender) {
                Image.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create();
            Column.debugLine("pages/Work/ApplyForDetail/ApplyForDetail.ets(124:7)");
            Column.padding({
                left: 10
            });
            Column.layoutWeight(1);
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create();
            Row.debugLine("pages/Work/ApplyForDetail/ApplyForDetail.ets(125:9)");
            Row.borderColor({ bottom: '#efefef' });
            Row.borderWidth({ bottom: 1 });
            Row.justifyContent(FlexAlign.SpaceBetween);
            Row.width('100%');
            Row.height(80);
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create();
            Column.debugLine("pages/Work/ApplyForDetail/ApplyForDetail.ets(126:11)");
            Column.alignItems(HorizontalAlign.Start);
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create("魏茜茜");
            Text.debugLine("pages/Work/ApplyForDetail/ApplyForDetail.ets(127:13)");
            Text.fontSize(20);
            Text.fontColor('#101010');
            Text.fontWeight(FontWeight.Bold);
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create("发起申请");
            Text.debugLine("pages/Work/ApplyForDetail/ApplyForDetail.ets(128:13)");
            Text.fontSize(16);
            Text.fontColor('#666666');
            Text.margin({
                top: 10
            });
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        Column.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create("2022-12-07 15:00");
            Text.debugLine("pages/Work/ApplyForDetail/ApplyForDetail.ets(135:11)");
            Text.fontSize(14);
            Text.fontColor('#9999a3');
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        Row.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create();
            Row.debugLine("pages/Work/ApplyForDetail/ApplyForDetail.ets(143:9)");
            Row.borderColor({ bottom: '#efefef' });
            Row.borderWidth({ bottom: 1 });
            Row.alignItems(VerticalAlign.Center);
            Row.justifyContent(FlexAlign.SpaceBetween);
            Row.width('100%');
            Row.height(80);
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create();
            Column.debugLine("pages/Work/ApplyForDetail/ApplyForDetail.ets(144:11)");
            Column.alignItems(HorizontalAlign.Start);
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create();
            Row.debugLine("pages/Work/ApplyForDetail/ApplyForDetail.ets(145:13)");
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create("张云");
            Text.debugLine("pages/Work/ApplyForDetail/ApplyForDetail.ets(146:15)");
            Text.fontSize(20);
            Text.fontColor('#101010');
            Text.fontWeight(FontWeight.Bold);
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create("部门领导");
            Text.debugLine("pages/Work/ApplyForDetail/ApplyForDetail.ets(147:15)");
            Text.padding(5);
            Text.fontSize(12);
            Text.margin({ left: 15 });
            Text.borderRadius(5);
            Text.backgroundColor('#eaeaff');
            Text.height(22);
            Text.fontColor('#6a6bcd');
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        Row.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create("已审批");
            Text.debugLine("pages/Work/ApplyForDetail/ApplyForDetail.ets(157:13)");
            Text.fontSize(16);
            Text.fontColor('#666666');
            Text.margin({
                top: 10
            });
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        Column.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create("2022-12-07 15:00");
            Text.debugLine("pages/Work/ApplyForDetail/ApplyForDetail.ets(164:11)");
            Text.fontSize(14);
            Text.fontColor('#9999a3');
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        Row.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create();
            Row.debugLine("pages/Work/ApplyForDetail/ApplyForDetail.ets(173:9)");
            Row.alignItems(VerticalAlign.Center);
            Row.justifyContent(FlexAlign.SpaceBetween);
            Row.width('100%');
            Row.height(80);
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create();
            Column.debugLine("pages/Work/ApplyForDetail/ApplyForDetail.ets(174:11)");
            Column.alignItems(HorizontalAlign.Start);
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create();
            Row.debugLine("pages/Work/ApplyForDetail/ApplyForDetail.ets(175:13)");
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create("梨花");
            Text.debugLine("pages/Work/ApplyForDetail/ApplyForDetail.ets(176:15)");
            Text.fontSize(20);
            Text.fontColor('#101010');
            Text.fontWeight(FontWeight.Bold);
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create("人事部");
            Text.debugLine("pages/Work/ApplyForDetail/ApplyForDetail.ets(177:15)");
            Text.padding(5);
            Text.fontSize(12);
            Text.margin({ left: 15 });
            Text.borderRadius(5);
            Text.backgroundColor('#eaeaff');
            Text.height(22);
            Text.fontColor('#6a6bcd');
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        Row.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create("等待审批");
            Text.debugLine("pages/Work/ApplyForDetail/ApplyForDetail.ets(187:13)");
            Text.fontSize(16);
            Text.fontColor('#ff5f35');
            Text.margin({
                top: 10
            });
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        Column.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create("2022-12-07 15:00");
            Text.debugLine("pages/Work/ApplyForDetail/ApplyForDetail.ets(194:11)");
            Text.fontSize(14);
            Text.fontColor('#9999a3');
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        Row.pop();
        Column.pop();
        Row.pop();
    }
    initialRender() {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create();
            Column.debugLine("pages/Work/ApplyForDetail/ApplyForDetail.ets(215:5)");
            Column.width('100%');
            Column.height('100%');
            Column.backgroundColor('#f5f5f5');
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        {
            this.observeComponentCreation((elmtId, isInitialRender) => {
                ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                if (isInitialRender) {
                    ViewPU.create(new 
                    // 导航栏
                    NavBar(this, {
                        title: "申请详情"
                    }, undefined, elmtId));
                }
                else {
                    this.updateStateVarsOfChildByElmtId(elmtId, {
                        title: "申请详情"
                    });
                }
                ViewStackProcessor.StopGetAccessRecording();
            });
        }
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            List.create();
            List.debugLine("pages/Work/ApplyForDetail/ApplyForDetail.ets(221:7)");
            List.padding(15);
            List.layoutWeight(1);
            if (!isInitialRender) {
                List.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        // 构建头部
        this.buildHeader.bind(this)();
        // 构建详情内容
        this.buildContent.bind(this)();
        // 构建流程
        this.buildProcess.bind(this)();
        List.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
ViewStackProcessor.StartGetAccessRecordingFor(ViewStackProcessor.AllocateNewElmetIdForNextComponent());
loadDocument(new ApplyForDetail(undefined, {}));
ViewStackProcessor.StopGetAccessRecording();
//# sourceMappingURL=ApplyForDetail.js.map