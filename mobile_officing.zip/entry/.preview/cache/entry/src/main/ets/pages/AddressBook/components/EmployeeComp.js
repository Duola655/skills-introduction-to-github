import router from '@ohos:router';
export class EmployeeComp extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1) {
        super(parent, __localStorage, elmtId);
        this.__organization = new SynchedPropertyNesedObjectPU(params.organization, this, "organization");
        this.setInitiallyProvidedValue(params);
    }
    setInitiallyProvidedValue(params) {
        this.__organization.set(params.organization);
    }
    updateStateVars(params) {
        this.__organization.set(params.organization);
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__organization.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__organization.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    get organization() {
        return this.__organization.get();
    }
    buildEmployee(employee, parent = null) {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create();
            Row.debugLine("pages/AddressBook/components/EmployeeComp.ets(11:5)");
            Row.padding({ left: 30, top: 20, right: 20, bottom: 20 });
            Row.alignItems(VerticalAlign.Center);
            Row.width('100%');
            Row.height(80);
            Row.onClick(() => {
                router.pushUrl({
                    url: "pages/AddressBook/EmployeeDetail/EmployeeDetail",
                    params: employee
                });
            });
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create(employee.name ? employee.name.substring(0, 1) : "");
            Text.debugLine("pages/AddressBook/components/EmployeeComp.ets(12:7)");
            Text.width(50);
            Text.height(50);
            Text.borderRadius(50);
            Text.fontSize(18);
            Text.textAlign(TextAlign.Center);
            Text.fontColor(Color.White);
            Text.backgroundColor('#6467d3');
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create(employee.name);
            Text.debugLine("pages/AddressBook/components/EmployeeComp.ets(20:7)");
            Text.fontSize(20);
            Text.fontWeight(FontWeight.Bold);
            Text.margin({ left: 10 });
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        Row.pop();
    }
    initialRender() {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            If.create();
            if (this.organization.expand) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation((elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        Column.create();
                        Column.debugLine("pages/AddressBook/components/EmployeeComp.ets(39:7)");
                        if (!isInitialRender) {
                            Column.pop();
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    });
                    this.observeComponentCreation((elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        ForEach.create();
                        const forEachItemGenFunction = _item => {
                            const employee = _item;
                            this.buildEmployee.bind(this)(employee);
                        };
                        this.forEachUpdateFunction(elmtId, this.organization.employees, forEachItemGenFunction);
                        if (!isInitialRender) {
                            ForEach.pop();
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    });
                    ForEach.pop();
                    Column.pop();
                });
            }
            else {
                If.branchId(1);
            }
            if (!isInitialRender) {
                If.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        If.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
//# sourceMappingURL=EmployeeComp.js.map