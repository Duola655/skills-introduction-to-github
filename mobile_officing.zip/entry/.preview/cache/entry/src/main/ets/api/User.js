import http from '@ohos:net.http';
import { request } from '@bundle:top.huangjiangjun.mobile_officing/entry/ets/utils/Request';
// 登录
export const login = (extraData) => {
    return request({
        url: 'user/login',
        method: http.RequestMethod.POST,
        extraData
    });
};
//# sourceMappingURL=User.js.map