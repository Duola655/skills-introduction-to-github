import { NavBar } from '@bundle:top.huangjiangjun.mobile_officing/entry/ets/components/NavBar';
import { getProcessList } from '@bundle:top.huangjiangjun.mobile_officing/entry/ets/api/Process';
import { ApplyForItem } from '@bundle:top.huangjiangjun.mobile_officing/entry/ets/components/ApplyForItem';
class MyApplyFor extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1) {
        super(parent, __localStorage, elmtId);
        this.__currentIndex = new ObservedPropertySimplePU(0, this, "currentIndex");
        this.__type_id = new ObservedPropertySimplePU(0, this, "type_id");
        this.__page = new ObservedPropertySimplePU(1, this, "page");
        this.__pageSize = new ObservedPropertySimplePU(10, this, "pageSize");
        this.__processList = new ObservedPropertyObjectPU([], this, "processList");
        this.setInitiallyProvidedValue(params);
    }
    setInitiallyProvidedValue(params) {
        if (params.currentIndex !== undefined) {
            this.currentIndex = params.currentIndex;
        }
        if (params.type_id !== undefined) {
            this.type_id = params.type_id;
        }
        if (params.page !== undefined) {
            this.page = params.page;
        }
        if (params.pageSize !== undefined) {
            this.pageSize = params.pageSize;
        }
        if (params.processList !== undefined) {
            this.processList = params.processList;
        }
    }
    updateStateVars(params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__currentIndex.purgeDependencyOnElmtId(rmElmtId);
        this.__type_id.purgeDependencyOnElmtId(rmElmtId);
        this.__page.purgeDependencyOnElmtId(rmElmtId);
        this.__pageSize.purgeDependencyOnElmtId(rmElmtId);
        this.__processList.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__currentIndex.aboutToBeDeleted();
        this.__type_id.aboutToBeDeleted();
        this.__page.aboutToBeDeleted();
        this.__pageSize.aboutToBeDeleted();
        this.__processList.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    get currentIndex() {
        return this.__currentIndex.get();
    }
    set currentIndex(newValue) {
        this.__currentIndex.set(newValue);
    }
    get type_id() {
        return this.__type_id.get();
    }
    set type_id(newValue) {
        this.__type_id.set(newValue);
    }
    get page() {
        return this.__page.get();
    }
    set page(newValue) {
        this.__page.set(newValue);
    }
    get pageSize() {
        return this.__pageSize.get();
    }
    set pageSize(newValue) {
        this.__pageSize.set(newValue);
    }
    get processList() {
        return this.__processList.get();
    }
    set processList(newValue) {
        this.__processList.set(newValue);
    }
    async getProcessListData() {
        const res = await getProcessList({
            type_id: this.type_id,
            page: this.page,
            pageSize: this.pageSize
        });
        this.processList = res.data.items;
    }
    aboutToAppear() {
        this.getProcessListData();
    }
    TabBuilder(index, tabTitle, parent = null) {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create();
            Column.debugLine("pages/Work/MyApplyFor/MyApplyFor.ets(30:5)");
            Column.width('100%');
            Column.height('100%');
            Column.backgroundColor(Color.White);
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create(tabTitle);
            Text.debugLine("pages/Work/MyApplyFor/MyApplyFor.ets(31:7)");
            Text.fontColor(this.currentIndex === index ? '#101010' : '#666666');
            Text.fontSize(this.currentIndex === index ? 18 : 17);
            Text.fontWeight(this.currentIndex === index ? 500 : 400);
            Text.margin({ top: 10, right: 5, bottom: 10 });
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Divider.create();
            Divider.debugLine("pages/Work/MyApplyFor/MyApplyFor.ets(37:7)");
            Divider.strokeWidth(2);
            Divider.color('#0475fa');
            Divider.opacity(this.currentIndex === index ? 1 : 0);
            Divider.width('50%');
            if (!isInitialRender) {
                Divider.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Column.pop();
    }
    buildApplyForItems(parent = null) {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create();
            Column.debugLine("pages/Work/MyApplyFor/MyApplyFor.ets(49:5)");
            Column.padding(15);
            Column.width('100%');
            Column.height('100%');
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            List.create();
            List.debugLine("pages/Work/MyApplyFor/MyApplyFor.ets(50:7)");
            List.backgroundColor(Color.White);
            List.borderRadius(5);
            if (!isInitialRender) {
                List.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            ForEach.create();
            const forEachItemGenFunction = _item => {
                const process = _item;
                {
                    const isLazyCreate = true;
                    const itemCreation = (elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        ListItem.create(deepRenderFunction, isLazyCreate);
                        ListItem.debugLine("pages/Work/MyApplyFor/MyApplyFor.ets(52:11)");
                        if (!isInitialRender) {
                            ListItem.pop();
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    };
                    const observedShallowRender = () => {
                        this.observeComponentCreation(itemCreation);
                        ListItem.pop();
                    };
                    const observedDeepRender = () => {
                        this.observeComponentCreation(itemCreation);
                        {
                            this.observeComponentCreation((elmtId, isInitialRender) => {
                                ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                                if (isInitialRender) {
                                    ViewPU.create(new ApplyForItem(this, { process }, undefined, elmtId));
                                }
                                else {
                                    this.updateStateVarsOfChildByElmtId(elmtId, {
                                        process
                                    });
                                }
                                ViewStackProcessor.StopGetAccessRecording();
                            });
                        }
                        ListItem.pop();
                    };
                    const deepRenderFunction = (elmtId, isInitialRender) => {
                        itemCreation(elmtId, isInitialRender);
                        this.updateFuncByElmtId.set(elmtId, itemCreation);
                        {
                            this.observeComponentCreation((elmtId, isInitialRender) => {
                                ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                                if (isInitialRender) {
                                    ViewPU.create(new ApplyForItem(this, { process }, undefined, elmtId));
                                }
                                else {
                                    this.updateStateVarsOfChildByElmtId(elmtId, {
                                        process
                                    });
                                }
                                ViewStackProcessor.StopGetAccessRecording();
                            });
                        }
                        ListItem.pop();
                    };
                    if (isLazyCreate) {
                        observedShallowRender();
                    }
                    else {
                        observedDeepRender();
                    }
                }
            };
            this.forEachUpdateFunction(elmtId, this.processList, forEachItemGenFunction);
            if (!isInitialRender) {
                ForEach.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        ForEach.pop();
        List.pop();
        Column.pop();
    }
    buildTopTab(parent = null) {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Tabs.create({ barPosition: BarPosition.Start });
            Tabs.debugLine("pages/Work/MyApplyFor/MyApplyFor.ets(66:5)");
            Tabs.onChange(index => {
                this.currentIndex = index;
                this.type_id = index;
                this.getProcessListData();
            });
            Tabs.layoutWeight(1);
            Tabs.backgroundColor('#f5f5f5');
            if (!isInitialRender) {
                Tabs.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            TabContent.create(() => {
                this.buildApplyForItems.bind(this)();
            });
            TabContent.tabBar({ builder: () => {
                    this.TabBuilder.call(this, 0, '全部');
                } });
            TabContent.debugLine("pages/Work/MyApplyFor/MyApplyFor.ets(67:7)");
            if (!isInitialRender) {
                TabContent.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        TabContent.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            TabContent.create(() => {
                this.buildApplyForItems.bind(this)();
            });
            TabContent.tabBar({ builder: () => {
                    this.TabBuilder.call(this, 1, '人事管理');
                } });
            TabContent.debugLine("pages/Work/MyApplyFor/MyApplyFor.ets(71:7)");
            if (!isInitialRender) {
                TabContent.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        TabContent.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            TabContent.create(() => {
                this.buildApplyForItems.bind(this)();
            });
            TabContent.tabBar({ builder: () => {
                    this.TabBuilder.call(this, 2, '行政事务');
                } });
            TabContent.debugLine("pages/Work/MyApplyFor/MyApplyFor.ets(75:7)");
            if (!isInitialRender) {
                TabContent.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        TabContent.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            TabContent.create(() => {
                this.buildApplyForItems.bind(this)();
            });
            TabContent.tabBar({ builder: () => {
                    this.TabBuilder.call(this, 3, '财务类');
                } });
            TabContent.debugLine("pages/Work/MyApplyFor/MyApplyFor.ets(79:7)");
            if (!isInitialRender) {
                TabContent.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        TabContent.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            TabContent.create(() => {
                this.buildApplyForItems.bind(this)();
            });
            TabContent.tabBar({ builder: () => {
                    this.TabBuilder.call(this, 4, '业务相关');
                } });
            TabContent.debugLine("pages/Work/MyApplyFor/MyApplyFor.ets(83:7)");
            if (!isInitialRender) {
                TabContent.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        TabContent.pop();
        Tabs.pop();
    }
    initialRender() {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create();
            Column.debugLine("pages/Work/MyApplyFor/MyApplyFor.ets(97:5)");
            Column.width('100%');
            Column.height('100%');
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        {
            this.observeComponentCreation((elmtId, isInitialRender) => {
                ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                if (isInitialRender) {
                    ViewPU.create(new 
                    // 顶部的NavBar组件
                    NavBar(this, { title: "我的申请" }, undefined, elmtId));
                }
                else {
                    this.updateStateVarsOfChildByElmtId(elmtId, {
                        title: "我的申请"
                    });
                }
                ViewStackProcessor.StopGetAccessRecording();
            });
        }
        // 使用Tab渲染内容
        this.buildTopTab.bind(this)();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
ViewStackProcessor.StartGetAccessRecordingFor(ViewStackProcessor.AllocateNewElmetIdForNextComponent());
loadDocument(new MyApplyFor(undefined, {}));
ViewStackProcessor.StopGetAccessRecording();
//# sourceMappingURL=MyApplyFor.js.map