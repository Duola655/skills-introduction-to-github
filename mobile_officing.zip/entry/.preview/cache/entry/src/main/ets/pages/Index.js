import router from '@ohos:router';
import PreferencesUtil from '@bundle:top.huangjiangjun.mobile_officing/entry/ets/utils/PreferencesUtil';
class Index extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1) {
        super(parent, __localStorage, elmtId);
        this.__time = new ObservedPropertySimplePU(3, this, "time");
        this.timer = -1;
        this.setInitiallyProvidedValue(params);
    }
    setInitiallyProvidedValue(params) {
        if (params.time !== undefined) {
            this.time = params.time;
        }
        if (params.timer !== undefined) {
            this.timer = params.timer;
        }
    }
    updateStateVars(params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__time.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__time.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    get time() {
        return this.__time.get();
    }
    set time(newValue) {
        this.__time.set(newValue);
    }
    async enter() {
        const token = await PreferencesUtil.getToken();
        if (token) { // 登录了
            router.replaceUrl({
                url: "pages/Home/Home"
            });
        }
        else {
            router.replaceUrl({
                url: "pages/Login/Login"
            });
        }
    }
    onPageShow() {
        this.timer = setInterval(() => {
            this.time--;
            if (this.time < 1) {
                // 跳转到登录页面
                this.enter();
                clearInterval(this.timer);
            }
        }, 1000);
    }
    initialRender() {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Stack.create({ alignContent: Alignment.Bottom });
            Stack.debugLine("pages/Index.ets(36:5)");
            Stack.width('100%');
            Stack.height('100%');
            if (!isInitialRender) {
                Stack.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Stack.create({ alignContent: Alignment.TopEnd });
            Stack.debugLine("pages/Index.ets(37:7)");
            if (!isInitialRender) {
                Stack.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Image.create({ "id": 0, "type": 30000, params: ["index/launch-screen.png"], "bundleName": "top.huangjiangjun.mobile_officing", "moduleName": "entry" });
            Image.debugLine("pages/Index.ets(38:9)");
            Image.width('100%');
            Image.height('100%');
            if (!isInitialRender) {
                Image.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create();
            Row.debugLine("pages/Index.ets(41:9)");
            Row.width(50);
            Row.height(50);
            Row.borderRadius(25);
            Row.margin({
                top: 15,
                right: 15
            });
            Row.backgroundColor(Color.White);
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create(`${this.time}`);
            Text.debugLine("pages/Index.ets(42:11)");
            Text.fontSize(30);
            Text.fontColor(Color.Gray);
            Text.width('100%');
            Text.textAlign(TextAlign.Center);
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        Row.pop();
        Stack.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Button.createWithLabel("");
            Button.debugLine("pages/Index.ets(58:7)");
            Button.width(200);
            Button.height(50);
            Button.margin({
                bottom: 88
            });
            Button.onClick(() => {
                this.enter();
            });
            Button.backgroundColor(Color.Transparent);
            if (!isInitialRender) {
                Button.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Button.pop();
        Stack.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
ViewStackProcessor.StartGetAccessRecordingFor(ViewStackProcessor.AllocateNewElmetIdForNextComponent());
loadDocument(new Index(undefined, {}));
ViewStackProcessor.StopGetAccessRecording();
//# sourceMappingURL=Index.js.map