import { request } from '@bundle:top.huangjiangjun.mobile_officing/entry/ets/utils/Request';
// 获取常用联系人（雇员）列表
export const getEmployeeList = () => {
    return request({
        url: 'employee/list'
    });
};
// 获取组织结构（部门）列表
export const getDepartmentList = () => {
    return request({
        url: 'employee/department/list'
    });
};
//# sourceMappingURL=AddressBook.js.map