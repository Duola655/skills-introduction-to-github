import { NavBar } from '@bundle:top.huangjiangjun.mobile_officing/entry/ets/components/NavBar';
import promptAction from '@ohos:promptAction';
import { addProcess } from '@bundle:top.huangjiangjun.mobile_officing/entry/ets/api/Process';
import router from '@ohos:router';
class LeaveApplication extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1) {
        super(parent, __localStorage, elmtId);
        this.typies = [
            { value: '年假' },
            { value: '事假' },
            { value: '病假' },
            { value: '调休' },
            { value: '婚假' },
            { value: '其他' }
        ];
        this.type = '';
        this.reason = '';
        this.submit = async () => {
            if (this.type === '') {
                promptAction.showToast({
                    message: "请假类型不能为空",
                    duration: 800,
                    bottom: 400
                });
                return;
            }
            if (this.reason === '') {
                promptAction.showToast({
                    message: "请假事由不能为空",
                    duration: 800,
                    bottom: 400
                });
                return;
            }
            // 准备好数据
            const extraData = {
                "type_id": "1",
                "type": "请假申请",
                "department": "技术部",
                "reason": this.reason,
                "days": "1",
                "initiator": "张三"
            };
            const res = await addProcess(extraData);
            promptAction.showToast({
                message: res.message,
                duration: 800,
                bottom: 400
            });
            if (res.code === 200) {
                setTimeout(() => {
                    router.replaceUrl({
                        url: "pages/Work/MyApplyFor/MyApplyFor"
                    });
                }, 1000);
            }
        };
        this.setInitiallyProvidedValue(params);
    }
    setInitiallyProvidedValue(params) {
        if (params.typies !== undefined) {
            this.typies = params.typies;
        }
        if (params.type !== undefined) {
            this.type = params.type;
        }
        if (params.reason !== undefined) {
            this.reason = params.reason;
        }
        if (params.submit !== undefined) {
            this.submit = params.submit;
        }
    }
    updateStateVars(params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
    }
    aboutToBeDeleted() {
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    initialRender() {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Stack.create();
            Stack.debugLine("pages/Work/LeaveApplication/LeaveApplication.ets(67:5)");
            Stack.width('100%');
            Stack.height('100%');
            Stack.backgroundColor('#f5f5f5');
            Stack.alignContent(Alignment.TopStart);
            if (!isInitialRender) {
                Stack.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        {
            this.observeComponentCreation((elmtId, isInitialRender) => {
                ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                if (isInitialRender) {
                    ViewPU.create(new NavBar(this, { title: "请假申请" }, undefined, elmtId));
                }
                else {
                    this.updateStateVarsOfChildByElmtId(elmtId, {
                        title: "请假申请"
                    });
                }
                ViewStackProcessor.StopGetAccessRecording();
            });
        }
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            // NavBar
            Stack.create();
            Stack.debugLine("pages/Work/LeaveApplication/LeaveApplication.ets(70:7)");
            // NavBar
            Stack.alignContent(Alignment.BottomEnd);
            // NavBar
            Stack.width('100%');
            // NavBar
            Stack.height('100%');
            if (!isInitialRender) {
                // NavBar
                Stack.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            List.create();
            List.debugLine("pages/Work/LeaveApplication/LeaveApplication.ets(71:9)");
            List.padding({
                bottom: 100
            });
            if (!isInitialRender) {
                List.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        {
            const isLazyCreate = true;
            const itemCreation = (elmtId, isInitialRender) => {
                ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                ListItem.create(deepRenderFunction, isLazyCreate);
                ListItem.debugLine("pages/Work/LeaveApplication/LeaveApplication.ets(72:11)");
                if (!isInitialRender) {
                    ListItem.pop();
                }
                ViewStackProcessor.StopGetAccessRecording();
            };
            const observedShallowRender = () => {
                this.observeComponentCreation(itemCreation);
                ListItem.pop();
            };
            const observedDeepRender = () => {
                this.observeComponentCreation(itemCreation);
                this.observeComponentCreation((elmtId, isInitialRender) => {
                    ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                    Column.create();
                    Column.debugLine("pages/Work/LeaveApplication/LeaveApplication.ets(73:13)");
                    if (!isInitialRender) {
                        Column.pop();
                    }
                    ViewStackProcessor.StopGetAccessRecording();
                });
                this.observeComponentCreation((elmtId, isInitialRender) => {
                    ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                    // 2、请假类型
                    Row.create();
                    Row.debugLine("pages/Work/LeaveApplication/LeaveApplication.ets(75:15)");
                    // 2、请假类型
                    Row.justifyContent(FlexAlign.SpaceBetween);
                    // 2、请假类型
                    Row.padding({
                        left: 10,
                        right: 10
                    });
                    // 2、请假类型
                    Row.width('100%');
                    // 2、请假类型
                    Row.height(80);
                    // 2、请假类型
                    Row.backgroundColor(Color.White);
                    if (!isInitialRender) {
                        // 2、请假类型
                        Row.pop();
                    }
                    ViewStackProcessor.StopGetAccessRecording();
                });
                this.observeComponentCreation((elmtId, isInitialRender) => {
                    ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                    Text.create("请假类型");
                    Text.debugLine("pages/Work/LeaveApplication/LeaveApplication.ets(76:17)");
                    Text.fontSize(28);
                    Text.fontWeight(FontWeight.Bold);
                    if (!isInitialRender) {
                        Text.pop();
                    }
                    ViewStackProcessor.StopGetAccessRecording();
                });
                Text.pop();
                this.observeComponentCreation((elmtId, isInitialRender) => {
                    ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                    Select.create(this.typies);
                    Select.debugLine("pages/Work/LeaveApplication/LeaveApplication.ets(80:17)");
                    Select.onSelect(index => {
                        this.type = this.typies[index].value;
                    });
                    Select.value('请选择');
                    Select.selected(1);
                    Select.font({ size: 20 });
                    Select.fontColor('#182431');
                    Select.selectedOptionFont({ size: 20, weight: 400 });
                    Select.optionFont({ size: 20, weight: 400 });
                    Select.selectedOptionBgColor('#f5f5f5');
                    Select.selectedOptionFontColor('#182431');
                    if (!isInitialRender) {
                        Select.pop();
                    }
                    ViewStackProcessor.StopGetAccessRecording();
                });
                Select.pop();
                // 2、请假类型
                Row.pop();
                this.observeComponentCreation((elmtId, isInitialRender) => {
                    ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                    // 3、请假事由
                    Row.create();
                    Row.debugLine("pages/Work/LeaveApplication/LeaveApplication.ets(103:15)");
                    // 3、请假事由
                    Row.alignItems(VerticalAlign.Top);
                    // 3、请假事由
                    Row.margin({ top: 20 });
                    // 3、请假事由
                    Row.width('100%');
                    // 3、请假事由
                    Row.height(300);
                    // 3、请假事由
                    Row.backgroundColor(Color.White);
                    if (!isInitialRender) {
                        // 3、请假事由
                        Row.pop();
                    }
                    ViewStackProcessor.StopGetAccessRecording();
                });
                this.observeComponentCreation((elmtId, isInitialRender) => {
                    ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                    Column.create();
                    Column.debugLine("pages/Work/LeaveApplication/LeaveApplication.ets(104:17)");
                    if (!isInitialRender) {
                        Column.pop();
                    }
                    ViewStackProcessor.StopGetAccessRecording();
                });
                this.observeComponentCreation((elmtId, isInitialRender) => {
                    ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                    Text.create("请假事由");
                    Text.debugLine("pages/Work/LeaveApplication/LeaveApplication.ets(105:19)");
                    Text.fontSize(28);
                    Text.fontWeight(FontWeight.Bold);
                    Text.width('100%');
                    Text.padding(10);
                    if (!isInitialRender) {
                        Text.pop();
                    }
                    ViewStackProcessor.StopGetAccessRecording();
                });
                Text.pop();
                this.observeComponentCreation((elmtId, isInitialRender) => {
                    ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                    TextArea.create({ placeholder: "请输入" });
                    TextArea.debugLine("pages/Work/LeaveApplication/LeaveApplication.ets(110:19)");
                    TextArea.onChange(value => {
                        this.reason = value;
                    });
                    TextArea.margin({ top: 10 });
                    TextArea.placeholderFont({ size: 20 });
                    TextArea.fontSize(20);
                    TextArea.layoutWeight(1);
                    TextArea.borderRadius(0);
                    TextArea.backgroundColor(Color.White);
                    if (!isInitialRender) {
                        TextArea.pop();
                    }
                    ViewStackProcessor.StopGetAccessRecording();
                });
                Column.pop();
                // 3、请假事由
                Row.pop();
                this.observeComponentCreation((elmtId, isInitialRender) => {
                    ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                    // 4、审批流程
                    Row.create();
                    Row.debugLine("pages/Work/LeaveApplication/LeaveApplication.ets(129:15)");
                    // 4、审批流程
                    Row.margin({ top: 20 });
                    // 4、审批流程
                    Row.width('100%');
                    // 4、审批流程
                    Row.height(160);
                    // 4、审批流程
                    Row.backgroundColor(Color.White);
                    if (!isInitialRender) {
                        // 4、审批流程
                        Row.pop();
                    }
                    ViewStackProcessor.StopGetAccessRecording();
                });
                this.observeComponentCreation((elmtId, isInitialRender) => {
                    ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                    Column.create();
                    Column.debugLine("pages/Work/LeaveApplication/LeaveApplication.ets(130:17)");
                    if (!isInitialRender) {
                        Column.pop();
                    }
                    ViewStackProcessor.StopGetAccessRecording();
                });
                this.observeComponentCreation((elmtId, isInitialRender) => {
                    ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                    Text.create("审批流程");
                    Text.debugLine("pages/Work/LeaveApplication/LeaveApplication.ets(131:19)");
                    Text.fontSize(28);
                    Text.fontWeight(FontWeight.Bold);
                    Text.width('100%');
                    Text.padding(10);
                    if (!isInitialRender) {
                        Text.pop();
                    }
                    ViewStackProcessor.StopGetAccessRecording();
                });
                Text.pop();
                this.observeComponentCreation((elmtId, isInitialRender) => {
                    ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                    Row.create();
                    Row.debugLine("pages/Work/LeaveApplication/LeaveApplication.ets(136:19)");
                    Row.justifyContent(FlexAlign.Start);
                    Row.alignItems(VerticalAlign.Top);
                    Row.padding({
                        left: 10,
                        right: 10
                    });
                    Row.width('100%');
                    Row.layoutWeight(1);
                    if (!isInitialRender) {
                        Row.pop();
                    }
                    ViewStackProcessor.StopGetAccessRecording();
                });
                this.observeComponentCreation((elmtId, isInitialRender) => {
                    ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                    Column.create();
                    Column.debugLine("pages/Work/LeaveApplication/LeaveApplication.ets(137:21)");
                    Column.height('100%');
                    if (!isInitialRender) {
                        Column.pop();
                    }
                    ViewStackProcessor.StopGetAccessRecording();
                });
                this.observeComponentCreation((elmtId, isInitialRender) => {
                    ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                    Text.create();
                    Text.debugLine("pages/Work/LeaveApplication/LeaveApplication.ets(138:23)");
                    Text.width(60);
                    Text.height(60);
                    Text.borderRadius(30);
                    Text.backgroundColor('#587fea');
                    if (!isInitialRender) {
                        Text.pop();
                    }
                    ViewStackProcessor.StopGetAccessRecording();
                });
                Text.pop();
                this.observeComponentCreation((elmtId, isInitialRender) => {
                    ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                    Text.create("发起人");
                    Text.debugLine("pages/Work/LeaveApplication/LeaveApplication.ets(143:23)");
                    Text.fontSize(18);
                    Text.fontColor('#666666');
                    Text.margin({
                        top: 10
                    });
                    if (!isInitialRender) {
                        Text.pop();
                    }
                    ViewStackProcessor.StopGetAccessRecording();
                });
                Text.pop();
                Column.pop();
                this.observeComponentCreation((elmtId, isInitialRender) => {
                    ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                    Image.create({ "id": 0, "type": 30000, params: ["common/arrow_right1.png"], "bundleName": "top.huangjiangjun.mobile_officing", "moduleName": "entry" });
                    Image.debugLine("pages/Work/LeaveApplication/LeaveApplication.ets(151:21)");
                    Image.objectFit(ImageFit.Cover);
                    Image.width(60);
                    Image.padding({ top: 10, left: 10, right: 10 });
                    if (!isInitialRender) {
                        Image.pop();
                    }
                    ViewStackProcessor.StopGetAccessRecording();
                });
                this.observeComponentCreation((elmtId, isInitialRender) => {
                    ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                    Column.create();
                    Column.debugLine("pages/Work/LeaveApplication/LeaveApplication.ets(156:21)");
                    Column.height('100%');
                    if (!isInitialRender) {
                        Column.pop();
                    }
                    ViewStackProcessor.StopGetAccessRecording();
                });
                this.observeComponentCreation((elmtId, isInitialRender) => {
                    ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                    Text.create();
                    Text.debugLine("pages/Work/LeaveApplication/LeaveApplication.ets(157:23)");
                    Text.width(60);
                    Text.height(60);
                    Text.borderRadius(30);
                    Text.backgroundColor('#587fea');
                    if (!isInitialRender) {
                        Text.pop();
                    }
                    ViewStackProcessor.StopGetAccessRecording();
                });
                Text.pop();
                this.observeComponentCreation((elmtId, isInitialRender) => {
                    ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                    Text.create("部门领导");
                    Text.debugLine("pages/Work/LeaveApplication/LeaveApplication.ets(162:23)");
                    Text.fontSize(18);
                    Text.fontColor('#666666');
                    Text.margin({
                        top: 10
                    });
                    if (!isInitialRender) {
                        Text.pop();
                    }
                    ViewStackProcessor.StopGetAccessRecording();
                });
                Text.pop();
                Column.pop();
                this.observeComponentCreation((elmtId, isInitialRender) => {
                    ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                    Image.create({ "id": 0, "type": 30000, params: ["common/arrow_right1.png"], "bundleName": "top.huangjiangjun.mobile_officing", "moduleName": "entry" });
                    Image.debugLine("pages/Work/LeaveApplication/LeaveApplication.ets(170:21)");
                    Image.objectFit(ImageFit.Cover);
                    Image.width(60);
                    Image.padding({ top: 10, left: 10, right: 10 });
                    if (!isInitialRender) {
                        Image.pop();
                    }
                    ViewStackProcessor.StopGetAccessRecording();
                });
                this.observeComponentCreation((elmtId, isInitialRender) => {
                    ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                    Column.create();
                    Column.debugLine("pages/Work/LeaveApplication/LeaveApplication.ets(174:21)");
                    Column.height('100%');
                    if (!isInitialRender) {
                        Column.pop();
                    }
                    ViewStackProcessor.StopGetAccessRecording();
                });
                this.observeComponentCreation((elmtId, isInitialRender) => {
                    ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                    Text.create();
                    Text.debugLine("pages/Work/LeaveApplication/LeaveApplication.ets(175:23)");
                    Text.width(60);
                    Text.height(60);
                    Text.borderRadius(30);
                    Text.backgroundColor('#587fea');
                    if (!isInitialRender) {
                        Text.pop();
                    }
                    ViewStackProcessor.StopGetAccessRecording();
                });
                Text.pop();
                this.observeComponentCreation((elmtId, isInitialRender) => {
                    ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                    Text.create("人事部");
                    Text.debugLine("pages/Work/LeaveApplication/LeaveApplication.ets(180:23)");
                    Text.fontSize(18);
                    Text.fontColor('#666666');
                    Text.margin({
                        top: 10
                    });
                    if (!isInitialRender) {
                        Text.pop();
                    }
                    ViewStackProcessor.StopGetAccessRecording();
                });
                Text.pop();
                Column.pop();
                Row.pop();
                Column.pop();
                // 4、审批流程
                Row.pop();
                this.observeComponentCreation((elmtId, isInitialRender) => {
                    ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                    // 5、抄送人
                    Row.create();
                    Row.debugLine("pages/Work/LeaveApplication/LeaveApplication.ets(204:15)");
                    // 5、抄送人
                    Row.padding(10);
                    // 5、抄送人
                    Row.margin({ top: 20 });
                    // 5、抄送人
                    Row.width('100%');
                    // 5、抄送人
                    Row.height(80);
                    // 5、抄送人
                    Row.justifyContent(FlexAlign.SpaceBetween);
                    // 5、抄送人
                    Row.backgroundColor(Color.White);
                    if (!isInitialRender) {
                        // 5、抄送人
                        Row.pop();
                    }
                    ViewStackProcessor.StopGetAccessRecording();
                });
                this.observeComponentCreation((elmtId, isInitialRender) => {
                    ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                    Text.create("抄送人");
                    Text.debugLine("pages/Work/LeaveApplication/LeaveApplication.ets(205:17)");
                    Text.fontSize(28);
                    Text.fontWeight(FontWeight.Bold);
                    if (!isInitialRender) {
                        Text.pop();
                    }
                    ViewStackProcessor.StopGetAccessRecording();
                });
                Text.pop();
                this.observeComponentCreation((elmtId, isInitialRender) => {
                    ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                    Text.create("+");
                    Text.debugLine("pages/Work/LeaveApplication/LeaveApplication.ets(209:17)");
                    Text.textAlign(TextAlign.Center);
                    Text.fontColor('#999999');
                    Text.fontSize(40);
                    Text.width(40);
                    Text.height(40);
                    Text.lineHeight(40);
                    Text.borderRadius(20);
                    Text.border({
                        width: 2,
                        color: '#999999'
                    });
                    if (!isInitialRender) {
                        Text.pop();
                    }
                    ViewStackProcessor.StopGetAccessRecording();
                });
                Text.pop();
                // 5、抄送人
                Row.pop();
                Column.pop();
                ListItem.pop();
            };
            const deepRenderFunction = (elmtId, isInitialRender) => {
                itemCreation(elmtId, isInitialRender);
                this.updateFuncByElmtId.set(elmtId, itemCreation);
                this.observeComponentCreation((elmtId, isInitialRender) => {
                    ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                    Column.create();
                    Column.debugLine("pages/Work/LeaveApplication/LeaveApplication.ets(73:13)");
                    if (!isInitialRender) {
                        Column.pop();
                    }
                    ViewStackProcessor.StopGetAccessRecording();
                });
                this.observeComponentCreation((elmtId, isInitialRender) => {
                    ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                    // 2、请假类型
                    Row.create();
                    Row.debugLine("pages/Work/LeaveApplication/LeaveApplication.ets(75:15)");
                    // 2、请假类型
                    Row.justifyContent(FlexAlign.SpaceBetween);
                    // 2、请假类型
                    Row.padding({
                        left: 10,
                        right: 10
                    });
                    // 2、请假类型
                    Row.width('100%');
                    // 2、请假类型
                    Row.height(80);
                    // 2、请假类型
                    Row.backgroundColor(Color.White);
                    if (!isInitialRender) {
                        // 2、请假类型
                        Row.pop();
                    }
                    ViewStackProcessor.StopGetAccessRecording();
                });
                this.observeComponentCreation((elmtId, isInitialRender) => {
                    ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                    Text.create("请假类型");
                    Text.debugLine("pages/Work/LeaveApplication/LeaveApplication.ets(76:17)");
                    Text.fontSize(28);
                    Text.fontWeight(FontWeight.Bold);
                    if (!isInitialRender) {
                        Text.pop();
                    }
                    ViewStackProcessor.StopGetAccessRecording();
                });
                Text.pop();
                this.observeComponentCreation((elmtId, isInitialRender) => {
                    ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                    Select.create(this.typies);
                    Select.debugLine("pages/Work/LeaveApplication/LeaveApplication.ets(80:17)");
                    Select.onSelect(index => {
                        this.type = this.typies[index].value;
                    });
                    Select.value('请选择');
                    Select.selected(1);
                    Select.font({ size: 20 });
                    Select.fontColor('#182431');
                    Select.selectedOptionFont({ size: 20, weight: 400 });
                    Select.optionFont({ size: 20, weight: 400 });
                    Select.selectedOptionBgColor('#f5f5f5');
                    Select.selectedOptionFontColor('#182431');
                    if (!isInitialRender) {
                        Select.pop();
                    }
                    ViewStackProcessor.StopGetAccessRecording();
                });
                Select.pop();
                // 2、请假类型
                Row.pop();
                this.observeComponentCreation((elmtId, isInitialRender) => {
                    ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                    // 3、请假事由
                    Row.create();
                    Row.debugLine("pages/Work/LeaveApplication/LeaveApplication.ets(103:15)");
                    // 3、请假事由
                    Row.alignItems(VerticalAlign.Top);
                    // 3、请假事由
                    Row.margin({ top: 20 });
                    // 3、请假事由
                    Row.width('100%');
                    // 3、请假事由
                    Row.height(300);
                    // 3、请假事由
                    Row.backgroundColor(Color.White);
                    if (!isInitialRender) {
                        // 3、请假事由
                        Row.pop();
                    }
                    ViewStackProcessor.StopGetAccessRecording();
                });
                this.observeComponentCreation((elmtId, isInitialRender) => {
                    ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                    Column.create();
                    Column.debugLine("pages/Work/LeaveApplication/LeaveApplication.ets(104:17)");
                    if (!isInitialRender) {
                        Column.pop();
                    }
                    ViewStackProcessor.StopGetAccessRecording();
                });
                this.observeComponentCreation((elmtId, isInitialRender) => {
                    ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                    Text.create("请假事由");
                    Text.debugLine("pages/Work/LeaveApplication/LeaveApplication.ets(105:19)");
                    Text.fontSize(28);
                    Text.fontWeight(FontWeight.Bold);
                    Text.width('100%');
                    Text.padding(10);
                    if (!isInitialRender) {
                        Text.pop();
                    }
                    ViewStackProcessor.StopGetAccessRecording();
                });
                Text.pop();
                this.observeComponentCreation((elmtId, isInitialRender) => {
                    ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                    TextArea.create({ placeholder: "请输入" });
                    TextArea.debugLine("pages/Work/LeaveApplication/LeaveApplication.ets(110:19)");
                    TextArea.onChange(value => {
                        this.reason = value;
                    });
                    TextArea.margin({ top: 10 });
                    TextArea.placeholderFont({ size: 20 });
                    TextArea.fontSize(20);
                    TextArea.layoutWeight(1);
                    TextArea.borderRadius(0);
                    TextArea.backgroundColor(Color.White);
                    if (!isInitialRender) {
                        TextArea.pop();
                    }
                    ViewStackProcessor.StopGetAccessRecording();
                });
                Column.pop();
                // 3、请假事由
                Row.pop();
                this.observeComponentCreation((elmtId, isInitialRender) => {
                    ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                    // 4、审批流程
                    Row.create();
                    Row.debugLine("pages/Work/LeaveApplication/LeaveApplication.ets(129:15)");
                    // 4、审批流程
                    Row.margin({ top: 20 });
                    // 4、审批流程
                    Row.width('100%');
                    // 4、审批流程
                    Row.height(160);
                    // 4、审批流程
                    Row.backgroundColor(Color.White);
                    if (!isInitialRender) {
                        // 4、审批流程
                        Row.pop();
                    }
                    ViewStackProcessor.StopGetAccessRecording();
                });
                this.observeComponentCreation((elmtId, isInitialRender) => {
                    ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                    Column.create();
                    Column.debugLine("pages/Work/LeaveApplication/LeaveApplication.ets(130:17)");
                    if (!isInitialRender) {
                        Column.pop();
                    }
                    ViewStackProcessor.StopGetAccessRecording();
                });
                this.observeComponentCreation((elmtId, isInitialRender) => {
                    ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                    Text.create("审批流程");
                    Text.debugLine("pages/Work/LeaveApplication/LeaveApplication.ets(131:19)");
                    Text.fontSize(28);
                    Text.fontWeight(FontWeight.Bold);
                    Text.width('100%');
                    Text.padding(10);
                    if (!isInitialRender) {
                        Text.pop();
                    }
                    ViewStackProcessor.StopGetAccessRecording();
                });
                Text.pop();
                this.observeComponentCreation((elmtId, isInitialRender) => {
                    ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                    Row.create();
                    Row.debugLine("pages/Work/LeaveApplication/LeaveApplication.ets(136:19)");
                    Row.justifyContent(FlexAlign.Start);
                    Row.alignItems(VerticalAlign.Top);
                    Row.padding({
                        left: 10,
                        right: 10
                    });
                    Row.width('100%');
                    Row.layoutWeight(1);
                    if (!isInitialRender) {
                        Row.pop();
                    }
                    ViewStackProcessor.StopGetAccessRecording();
                });
                this.observeComponentCreation((elmtId, isInitialRender) => {
                    ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                    Column.create();
                    Column.debugLine("pages/Work/LeaveApplication/LeaveApplication.ets(137:21)");
                    Column.height('100%');
                    if (!isInitialRender) {
                        Column.pop();
                    }
                    ViewStackProcessor.StopGetAccessRecording();
                });
                this.observeComponentCreation((elmtId, isInitialRender) => {
                    ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                    Text.create();
                    Text.debugLine("pages/Work/LeaveApplication/LeaveApplication.ets(138:23)");
                    Text.width(60);
                    Text.height(60);
                    Text.borderRadius(30);
                    Text.backgroundColor('#587fea');
                    if (!isInitialRender) {
                        Text.pop();
                    }
                    ViewStackProcessor.StopGetAccessRecording();
                });
                Text.pop();
                this.observeComponentCreation((elmtId, isInitialRender) => {
                    ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                    Text.create("发起人");
                    Text.debugLine("pages/Work/LeaveApplication/LeaveApplication.ets(143:23)");
                    Text.fontSize(18);
                    Text.fontColor('#666666');
                    Text.margin({
                        top: 10
                    });
                    if (!isInitialRender) {
                        Text.pop();
                    }
                    ViewStackProcessor.StopGetAccessRecording();
                });
                Text.pop();
                Column.pop();
                this.observeComponentCreation((elmtId, isInitialRender) => {
                    ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                    Image.create({ "id": 0, "type": 30000, params: ["common/arrow_right1.png"], "bundleName": "top.huangjiangjun.mobile_officing", "moduleName": "entry" });
                    Image.debugLine("pages/Work/LeaveApplication/LeaveApplication.ets(151:21)");
                    Image.objectFit(ImageFit.Cover);
                    Image.width(60);
                    Image.padding({ top: 10, left: 10, right: 10 });
                    if (!isInitialRender) {
                        Image.pop();
                    }
                    ViewStackProcessor.StopGetAccessRecording();
                });
                this.observeComponentCreation((elmtId, isInitialRender) => {
                    ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                    Column.create();
                    Column.debugLine("pages/Work/LeaveApplication/LeaveApplication.ets(156:21)");
                    Column.height('100%');
                    if (!isInitialRender) {
                        Column.pop();
                    }
                    ViewStackProcessor.StopGetAccessRecording();
                });
                this.observeComponentCreation((elmtId, isInitialRender) => {
                    ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                    Text.create();
                    Text.debugLine("pages/Work/LeaveApplication/LeaveApplication.ets(157:23)");
                    Text.width(60);
                    Text.height(60);
                    Text.borderRadius(30);
                    Text.backgroundColor('#587fea');
                    if (!isInitialRender) {
                        Text.pop();
                    }
                    ViewStackProcessor.StopGetAccessRecording();
                });
                Text.pop();
                this.observeComponentCreation((elmtId, isInitialRender) => {
                    ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                    Text.create("部门领导");
                    Text.debugLine("pages/Work/LeaveApplication/LeaveApplication.ets(162:23)");
                    Text.fontSize(18);
                    Text.fontColor('#666666');
                    Text.margin({
                        top: 10
                    });
                    if (!isInitialRender) {
                        Text.pop();
                    }
                    ViewStackProcessor.StopGetAccessRecording();
                });
                Text.pop();
                Column.pop();
                this.observeComponentCreation((elmtId, isInitialRender) => {
                    ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                    Image.create({ "id": 0, "type": 30000, params: ["common/arrow_right1.png"], "bundleName": "top.huangjiangjun.mobile_officing", "moduleName": "entry" });
                    Image.debugLine("pages/Work/LeaveApplication/LeaveApplication.ets(170:21)");
                    Image.objectFit(ImageFit.Cover);
                    Image.width(60);
                    Image.padding({ top: 10, left: 10, right: 10 });
                    if (!isInitialRender) {
                        Image.pop();
                    }
                    ViewStackProcessor.StopGetAccessRecording();
                });
                this.observeComponentCreation((elmtId, isInitialRender) => {
                    ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                    Column.create();
                    Column.debugLine("pages/Work/LeaveApplication/LeaveApplication.ets(174:21)");
                    Column.height('100%');
                    if (!isInitialRender) {
                        Column.pop();
                    }
                    ViewStackProcessor.StopGetAccessRecording();
                });
                this.observeComponentCreation((elmtId, isInitialRender) => {
                    ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                    Text.create();
                    Text.debugLine("pages/Work/LeaveApplication/LeaveApplication.ets(175:23)");
                    Text.width(60);
                    Text.height(60);
                    Text.borderRadius(30);
                    Text.backgroundColor('#587fea');
                    if (!isInitialRender) {
                        Text.pop();
                    }
                    ViewStackProcessor.StopGetAccessRecording();
                });
                Text.pop();
                this.observeComponentCreation((elmtId, isInitialRender) => {
                    ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                    Text.create("人事部");
                    Text.debugLine("pages/Work/LeaveApplication/LeaveApplication.ets(180:23)");
                    Text.fontSize(18);
                    Text.fontColor('#666666');
                    Text.margin({
                        top: 10
                    });
                    if (!isInitialRender) {
                        Text.pop();
                    }
                    ViewStackProcessor.StopGetAccessRecording();
                });
                Text.pop();
                Column.pop();
                Row.pop();
                Column.pop();
                // 4、审批流程
                Row.pop();
                this.observeComponentCreation((elmtId, isInitialRender) => {
                    ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                    // 5、抄送人
                    Row.create();
                    Row.debugLine("pages/Work/LeaveApplication/LeaveApplication.ets(204:15)");
                    // 5、抄送人
                    Row.padding(10);
                    // 5、抄送人
                    Row.margin({ top: 20 });
                    // 5、抄送人
                    Row.width('100%');
                    // 5、抄送人
                    Row.height(80);
                    // 5、抄送人
                    Row.justifyContent(FlexAlign.SpaceBetween);
                    // 5、抄送人
                    Row.backgroundColor(Color.White);
                    if (!isInitialRender) {
                        // 5、抄送人
                        Row.pop();
                    }
                    ViewStackProcessor.StopGetAccessRecording();
                });
                this.observeComponentCreation((elmtId, isInitialRender) => {
                    ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                    Text.create("抄送人");
                    Text.debugLine("pages/Work/LeaveApplication/LeaveApplication.ets(205:17)");
                    Text.fontSize(28);
                    Text.fontWeight(FontWeight.Bold);
                    if (!isInitialRender) {
                        Text.pop();
                    }
                    ViewStackProcessor.StopGetAccessRecording();
                });
                Text.pop();
                this.observeComponentCreation((elmtId, isInitialRender) => {
                    ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                    Text.create("+");
                    Text.debugLine("pages/Work/LeaveApplication/LeaveApplication.ets(209:17)");
                    Text.textAlign(TextAlign.Center);
                    Text.fontColor('#999999');
                    Text.fontSize(40);
                    Text.width(40);
                    Text.height(40);
                    Text.lineHeight(40);
                    Text.borderRadius(20);
                    Text.border({
                        width: 2,
                        color: '#999999'
                    });
                    if (!isInitialRender) {
                        Text.pop();
                    }
                    ViewStackProcessor.StopGetAccessRecording();
                });
                Text.pop();
                // 5、抄送人
                Row.pop();
                Column.pop();
                ListItem.pop();
            };
            if (isLazyCreate) {
                observedShallowRender();
            }
            else {
                observedDeepRender();
            }
        }
        List.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create();
            Row.debugLine("pages/Work/LeaveApplication/LeaveApplication.ets(235:9)");
            Row.justifyContent(FlexAlign.Center);
            Row.backgroundColor(Color.White);
            Row.alignItems(VerticalAlign.Center);
            Row.height(80);
            Row.width('100%');
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Button.createWithLabel("提交");
            Button.debugLine("pages/Work/LeaveApplication/LeaveApplication.ets(236:11)");
            Button.borderRadius(3);
            Button.height(60);
            Button.width('90%');
            Button.backgroundColor('#4749a1');
            Button.type(ButtonType.Normal);
            Button.onClick(() => {
                this.submit();
            });
            if (!isInitialRender) {
                Button.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Button.pop();
        Row.pop();
        // NavBar
        Stack.pop();
        Stack.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
ViewStackProcessor.StartGetAccessRecordingFor(ViewStackProcessor.AllocateNewElmetIdForNextComponent());
loadDocument(new LeaveApplication(undefined, {}));
ViewStackProcessor.StopGetAccessRecording();
//# sourceMappingURL=LeaveApplication.js.map