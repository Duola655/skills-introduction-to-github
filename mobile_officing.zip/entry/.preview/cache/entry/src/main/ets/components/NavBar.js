import router from '@ohos:router';
export class NavBar extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1) {
        super(parent, __localStorage, elmtId);
        this.__title = new SynchedPropertySimpleOneWayPU(params.title, this, "title");
        this.setInitiallyProvidedValue(params);
    }
    setInitiallyProvidedValue(params) {
    }
    updateStateVars(params) {
        this.__title.reset(params.title);
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__title.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__title.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    get title() {
        return this.__title.get();
    }
    set title(newValue) {
        this.__title.set(newValue);
    }
    initialRender() {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create();
            Row.debugLine("components/NavBar.ets(7:5)");
            Row.width('100%');
            Row.height(60);
            Row.padding({
                left: 10,
                right: 10
            });
            Row.justifyContent(FlexAlign.SpaceBetween);
            Row.backgroundColor(Color.White);
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            // 左边的返回
            Image.create({ "id": 0, "type": 30000, params: ["common/back.png"], "bundleName": "top.huangjiangjun.mobile_officing", "moduleName": "entry" });
            Image.debugLine("components/NavBar.ets(9:7)");
            // 左边的返回
            Image.width(20);
            // 左边的返回
            Image.height(20);
            // 左边的返回
            Image.onClick(() => {
                router.back();
            });
            if (!isInitialRender) {
                // 左边的返回
                Image.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            // 中间的标题
            Text.create(this.title);
            Text.debugLine("components/NavBar.ets(17:7)");
            // 中间的标题
            Text.fontSize(22);
            // 中间的标题
            Text.fontWeight(FontWeight.Bold);
            if (!isInitialRender) {
                // 中间的标题
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        // 中间的标题
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            // 右边
            Text.create("");
            Text.debugLine("components/NavBar.ets(22:7)");
            if (!isInitialRender) {
                // 右边
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        // 右边
        Text.pop();
        Row.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
//# sourceMappingURL=NavBar.js.map