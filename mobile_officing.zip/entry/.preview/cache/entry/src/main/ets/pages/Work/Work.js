import { getProcessList } from '@bundle:top.huangjiangjun.mobile_officing/entry/ets/api/Process';
import { ApplyForItem } from '@bundle:top.huangjiangjun.mobile_officing/entry/ets/components/ApplyForItem';
import router from '@ohos:router';
export class Work extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1) {
        super(parent, __localStorage, elmtId);
        this.__processList = new ObservedPropertyObjectPU([], this, "processList");
        this.setInitiallyProvidedValue(params);
    }
    setInitiallyProvidedValue(params) {
        if (params.processList !== undefined) {
            this.processList = params.processList;
        }
    }
    updateStateVars(params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__processList.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__processList.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    get processList() {
        return this.__processList.get();
    }
    set processList(newValue) {
        this.__processList.set(newValue);
    }
    async getProcessListData() {
        const res = await getProcessList({ type_id: 0, page: 1, pageSize: 2 });
        this.processList = res.data.items;
    }
    aboutToAppear() {
        this.getProcessListData();
    }
    // 构建头部
    buildTop(parent = null) {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create();
            Row.debugLine("pages/Work/Work.ets(21:5)");
            Row.padding({ left: 20, right: 20, bottom: 10 });
            Row.height('100vp');
            Row.width('100%');
            Row.alignItems(VerticalAlign.Bottom);
            Row.justifyContent(FlexAlign.SpaceBetween);
            Row.borderColor({ bottom: '#6a6cb2' });
            Row.borderWidth({ bottom: 1 });
            Row.backgroundColor('#4749a1');
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create("我的办公");
            Text.debugLine("pages/Work/Work.ets(22:7)");
            Text.fontSize('30sp');
            Text.fontColor(Color.White);
            Text.fontWeight(800);
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create();
            Row.debugLine("pages/Work/Work.ets(26:7)");
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create();
            Column.debugLine("pages/Work/Work.ets(27:9)");
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create("8℃");
            Text.debugLine("pages/Work/Work.ets(28:11)");
            Text.fontColor(Color.White);
            Text.fontWeight(800);
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create("12月8日");
            Text.debugLine("pages/Work/Work.ets(31:11)");
            Text.fontColor(Color.White);
            Text.margin({ top: 5 });
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        Column.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Image.create({ "id": 0, "type": 30000, params: ["work/weather.png"], "bundleName": "top.huangjiangjun.mobile_officing", "moduleName": "entry" });
            Image.debugLine("pages/Work/Work.ets(36:9)");
            Image.height(50);
            Image.width(50);
            if (!isInitialRender) {
                Image.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Row.pop();
        Row.pop();
    }
    // 提示信息
    buildTip(parent = null) {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create();
            Row.debugLine("pages/Work/Work.ets(53:5)");
            Row.padding({
                top: 30
            });
            Row.alignItems(VerticalAlign.Top);
            Row.justifyContent(FlexAlign.SpaceEvenly);
            Row.backgroundColor('#4749a1');
            Row.height(200);
            Row.width('100%');
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create();
            Column.debugLine("pages/Work/Work.ets(54:7)");
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create('待审批');
            Text.debugLine("pages/Work/Work.ets(55:9)");
            Text.fontSize(16);
            Text.fontColor('#8888cd');
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create('15');
            Text.debugLine("pages/Work/Work.ets(58:9)");
            Text.fontSize(26);
            Text.fontColor(Color.White);
            Text.fontWeight(800);
            Text.margin({ top: 15 });
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        Column.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create();
            Column.debugLine("pages/Work/Work.ets(65:7)");
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create('会议提醒');
            Text.debugLine("pages/Work/Work.ets(66:9)");
            Text.fontSize(16);
            Text.fontColor('#8888cd');
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create('2');
            Text.debugLine("pages/Work/Work.ets(69:9)");
            Text.fontSize(26);
            Text.fontColor(Color.White);
            Text.fontWeight(800);
            Text.margin({ top: 15 });
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        Column.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create();
            Column.debugLine("pages/Work/Work.ets(76:7)");
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create('周报');
            Text.debugLine("pages/Work/Work.ets(77:9)");
            Text.fontSize(16);
            Text.fontColor('#8888cd');
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create('1');
            Text.debugLine("pages/Work/Work.ets(80:9)");
            Text.fontSize(26);
            Text.fontColor(Color.White);
            Text.fontWeight(800);
            Text.margin({ top: 15 });
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        Column.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create();
            Column.debugLine("pages/Work/Work.ets(87:7)");
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create('工作汇报');
            Text.debugLine("pages/Work/Work.ets(88:9)");
            Text.fontSize(16);
            Text.fontColor('#8888cd');
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create('5');
            Text.debugLine("pages/Work/Work.ets(91:9)");
            Text.fontSize(26);
            Text.fontColor(Color.White);
            Text.fontWeight(800);
            Text.margin({ top: 15 });
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        Column.pop();
        Row.pop();
    }
    // 构建App每一项
    buildAppItem(image, text, parent = null) {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create();
            Column.debugLine("pages/Work/Work.ets(110:5)");
            Column.width('25%');
            Column.margin({
                bottom: 20
            });
            Column.onClick(() => {
                if (text == "请假申请") {
                    router.pushUrl({
                        url: "pages/Work/LeaveApplication/LeaveApplication"
                    });
                }
                else if (text == '考勤打卡') {
                    router.pushUrl({
                        url: "pages/Work/ClockIn/ClockIn"
                    });
                }
            });
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Image.create(image);
            Image.debugLine("pages/Work/Work.ets(111:7)");
            Image.width(50);
            Image.height(50);
            if (!isInitialRender) {
                Image.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create(text);
            Text.debugLine("pages/Work/Work.ets(114:7)");
            Text.margin({
                top: 10
            });
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        Column.pop();
    }
    // 构建App容器（使用Grid组件）
    buildAppContainer(parent = null) {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Grid.create();
            Grid.debugLine("pages/Work/Work.ets(138:5)");
            Grid.rowsGap(20);
            Grid.columnsTemplate("1fr 1fr 1fr 1fr");
            Grid.padding({
                top: 20,
                bottom: 20
            });
            if (!isInitialRender) {
                Grid.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        {
            const isLazyCreate = true && (Grid.willUseProxy() === true);
            const itemCreation = (elmtId, isInitialRender) => {
                ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                GridItem.create(deepRenderFunction, isLazyCreate);
                GridItem.debugLine("pages/Work/Work.ets(139:7)");
                if (!isInitialRender) {
                    GridItem.pop();
                }
                ViewStackProcessor.StopGetAccessRecording();
            };
            const observedShallowRender = () => {
                this.observeComponentCreation(itemCreation);
                GridItem.pop();
            };
            const observedDeepRender = () => {
                this.observeComponentCreation(itemCreation);
                this.buildAppItem.bind(this)({ "id": 0, "type": 30000, params: ["work/process.png"], "bundleName": "top.huangjiangjun.mobile_officing", "moduleName": "entry" }, "请假申请");
                GridItem.pop();
            };
            const deepRenderFunction = (elmtId, isInitialRender) => {
                itemCreation(elmtId, isInitialRender);
                this.updateFuncByElmtId.set(elmtId, itemCreation);
                this.buildAppItem.bind(this)({ "id": 0, "type": 30000, params: ["work/process.png"], "bundleName": "top.huangjiangjun.mobile_officing", "moduleName": "entry" }, "请假申请");
                GridItem.pop();
            };
            if (isLazyCreate) {
                observedShallowRender();
            }
            else {
                observedDeepRender();
            }
        }
        {
            const isLazyCreate = true && (Grid.willUseProxy() === true);
            const itemCreation = (elmtId, isInitialRender) => {
                ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                GridItem.create(deepRenderFunction, isLazyCreate);
                GridItem.debugLine("pages/Work/Work.ets(143:7)");
                if (!isInitialRender) {
                    GridItem.pop();
                }
                ViewStackProcessor.StopGetAccessRecording();
            };
            const observedShallowRender = () => {
                this.observeComponentCreation(itemCreation);
                GridItem.pop();
            };
            const observedDeepRender = () => {
                this.observeComponentCreation(itemCreation);
                this.buildAppItem.bind(this)({ "id": 0, "type": 30000, params: ["work/clock.png"], "bundleName": "top.huangjiangjun.mobile_officing", "moduleName": "entry" }, "考勤打卡");
                GridItem.pop();
            };
            const deepRenderFunction = (elmtId, isInitialRender) => {
                itemCreation(elmtId, isInitialRender);
                this.updateFuncByElmtId.set(elmtId, itemCreation);
                this.buildAppItem.bind(this)({ "id": 0, "type": 30000, params: ["work/clock.png"], "bundleName": "top.huangjiangjun.mobile_officing", "moduleName": "entry" }, "考勤打卡");
                GridItem.pop();
            };
            if (isLazyCreate) {
                observedShallowRender();
            }
            else {
                observedDeepRender();
            }
        }
        {
            const isLazyCreate = true && (Grid.willUseProxy() === true);
            const itemCreation = (elmtId, isInitialRender) => {
                ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                GridItem.create(deepRenderFunction, isLazyCreate);
                GridItem.debugLine("pages/Work/Work.ets(147:7)");
                if (!isInitialRender) {
                    GridItem.pop();
                }
                ViewStackProcessor.StopGetAccessRecording();
            };
            const observedShallowRender = () => {
                this.observeComponentCreation(itemCreation);
                GridItem.pop();
            };
            const observedDeepRender = () => {
                this.observeComponentCreation(itemCreation);
                this.buildAppItem.bind(this)({ "id": 0, "type": 30000, params: ["work/report.png"], "bundleName": "top.huangjiangjun.mobile_officing", "moduleName": "entry" }, "汇报");
                GridItem.pop();
            };
            const deepRenderFunction = (elmtId, isInitialRender) => {
                itemCreation(elmtId, isInitialRender);
                this.updateFuncByElmtId.set(elmtId, itemCreation);
                this.buildAppItem.bind(this)({ "id": 0, "type": 30000, params: ["work/report.png"], "bundleName": "top.huangjiangjun.mobile_officing", "moduleName": "entry" }, "汇报");
                GridItem.pop();
            };
            if (isLazyCreate) {
                observedShallowRender();
            }
            else {
                observedDeepRender();
            }
        }
        {
            const isLazyCreate = true && (Grid.willUseProxy() === true);
            const itemCreation = (elmtId, isInitialRender) => {
                ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                GridItem.create(deepRenderFunction, isLazyCreate);
                GridItem.debugLine("pages/Work/Work.ets(151:7)");
                if (!isInitialRender) {
                    GridItem.pop();
                }
                ViewStackProcessor.StopGetAccessRecording();
            };
            const observedShallowRender = () => {
                this.observeComponentCreation(itemCreation);
                GridItem.pop();
            };
            const observedDeepRender = () => {
                this.observeComponentCreation(itemCreation);
                this.buildAppItem.bind(this)({ "id": 0, "type": 30000, params: ["work/approve.png"], "bundleName": "top.huangjiangjun.mobile_officing", "moduleName": "entry" }, "OA审批");
                GridItem.pop();
            };
            const deepRenderFunction = (elmtId, isInitialRender) => {
                itemCreation(elmtId, isInitialRender);
                this.updateFuncByElmtId.set(elmtId, itemCreation);
                this.buildAppItem.bind(this)({ "id": 0, "type": 30000, params: ["work/approve.png"], "bundleName": "top.huangjiangjun.mobile_officing", "moduleName": "entry" }, "OA审批");
                GridItem.pop();
            };
            if (isLazyCreate) {
                observedShallowRender();
            }
            else {
                observedDeepRender();
            }
        }
        {
            const isLazyCreate = true && (Grid.willUseProxy() === true);
            const itemCreation = (elmtId, isInitialRender) => {
                ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                GridItem.create(deepRenderFunction, isLazyCreate);
                GridItem.debugLine("pages/Work/Work.ets(155:7)");
                if (!isInitialRender) {
                    GridItem.pop();
                }
                ViewStackProcessor.StopGetAccessRecording();
            };
            const observedShallowRender = () => {
                this.observeComponentCreation(itemCreation);
                GridItem.pop();
            };
            const observedDeepRender = () => {
                this.observeComponentCreation(itemCreation);
                this.buildAppItem.bind(this)({ "id": 0, "type": 30000, params: ["work/card.png"], "bundleName": "top.huangjiangjun.mobile_officing", "moduleName": "entry" }, "补卡申请");
                GridItem.pop();
            };
            const deepRenderFunction = (elmtId, isInitialRender) => {
                itemCreation(elmtId, isInitialRender);
                this.updateFuncByElmtId.set(elmtId, itemCreation);
                this.buildAppItem.bind(this)({ "id": 0, "type": 30000, params: ["work/card.png"], "bundleName": "top.huangjiangjun.mobile_officing", "moduleName": "entry" }, "补卡申请");
                GridItem.pop();
            };
            if (isLazyCreate) {
                observedShallowRender();
            }
            else {
                observedDeepRender();
            }
        }
        {
            const isLazyCreate = true && (Grid.willUseProxy() === true);
            const itemCreation = (elmtId, isInitialRender) => {
                ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                GridItem.create(deepRenderFunction, isLazyCreate);
                GridItem.debugLine("pages/Work/Work.ets(159:7)");
                if (!isInitialRender) {
                    GridItem.pop();
                }
                ViewStackProcessor.StopGetAccessRecording();
            };
            const observedShallowRender = () => {
                this.observeComponentCreation(itemCreation);
                GridItem.pop();
            };
            const observedDeepRender = () => {
                this.observeComponentCreation(itemCreation);
                this.buildAppItem.bind(this)({ "id": 0, "type": 30000, params: ["work/salary.png"], "bundleName": "top.huangjiangjun.mobile_officing", "moduleName": "entry" }, "工资单");
                GridItem.pop();
            };
            const deepRenderFunction = (elmtId, isInitialRender) => {
                itemCreation(elmtId, isInitialRender);
                this.updateFuncByElmtId.set(elmtId, itemCreation);
                this.buildAppItem.bind(this)({ "id": 0, "type": 30000, params: ["work/salary.png"], "bundleName": "top.huangjiangjun.mobile_officing", "moduleName": "entry" }, "工资单");
                GridItem.pop();
            };
            if (isLazyCreate) {
                observedShallowRender();
            }
            else {
                observedDeepRender();
            }
        }
        {
            const isLazyCreate = true && (Grid.willUseProxy() === true);
            const itemCreation = (elmtId, isInitialRender) => {
                ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                GridItem.create(deepRenderFunction, isLazyCreate);
                GridItem.debugLine("pages/Work/Work.ets(163:7)");
                if (!isInitialRender) {
                    GridItem.pop();
                }
                ViewStackProcessor.StopGetAccessRecording();
            };
            const observedShallowRender = () => {
                this.observeComponentCreation(itemCreation);
                GridItem.pop();
            };
            const observedDeepRender = () => {
                this.observeComponentCreation(itemCreation);
                this.buildAppItem.bind(this)({ "id": 0, "type": 30000, params: ["work/notice.png"], "bundleName": "top.huangjiangjun.mobile_officing", "moduleName": "entry" }, "公司公告");
                GridItem.pop();
            };
            const deepRenderFunction = (elmtId, isInitialRender) => {
                itemCreation(elmtId, isInitialRender);
                this.updateFuncByElmtId.set(elmtId, itemCreation);
                this.buildAppItem.bind(this)({ "id": 0, "type": 30000, params: ["work/notice.png"], "bundleName": "top.huangjiangjun.mobile_officing", "moduleName": "entry" }, "公司公告");
                GridItem.pop();
            };
            if (isLazyCreate) {
                observedShallowRender();
            }
            else {
                observedDeepRender();
            }
        }
        {
            const isLazyCreate = true && (Grid.willUseProxy() === true);
            const itemCreation = (elmtId, isInitialRender) => {
                ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                GridItem.create(deepRenderFunction, isLazyCreate);
                GridItem.debugLine("pages/Work/Work.ets(167:7)");
                if (!isInitialRender) {
                    GridItem.pop();
                }
                ViewStackProcessor.StopGetAccessRecording();
            };
            const observedShallowRender = () => {
                this.observeComponentCreation(itemCreation);
                GridItem.pop();
            };
            const observedDeepRender = () => {
                this.observeComponentCreation(itemCreation);
                this.buildAppItem.bind(this)({ "id": 0, "type": 30000, params: ["work/rule.png"], "bundleName": "top.huangjiangjun.mobile_officing", "moduleName": "entry" }, "规章制度");
                GridItem.pop();
            };
            const deepRenderFunction = (elmtId, isInitialRender) => {
                itemCreation(elmtId, isInitialRender);
                this.updateFuncByElmtId.set(elmtId, itemCreation);
                this.buildAppItem.bind(this)({ "id": 0, "type": 30000, params: ["work/rule.png"], "bundleName": "top.huangjiangjun.mobile_officing", "moduleName": "entry" }, "规章制度");
                GridItem.pop();
            };
            if (isLazyCreate) {
                observedShallowRender();
            }
            else {
                observedDeepRender();
            }
        }
        Grid.pop();
    }
    // 构建App容器（使用Flex组件）
    buildAppContainer2(parent = null) {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Flex.create({ wrap: FlexWrap.Wrap, alignContent: FlexAlign.SpaceBetween });
            Flex.debugLine("pages/Work/Work.ets(181:5)");
            Flex.padding({
                left: 15,
                right: 15,
                top: 20,
                bottom: 20
            });
            if (!isInitialRender) {
                Flex.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.buildAppItem.bind(this)({ "id": 0, "type": 30000, params: ["work/process.png"], "bundleName": "top.huangjiangjun.mobile_officing", "moduleName": "entry" }, "请假申请");
        this.buildAppItem.bind(this)({ "id": 0, "type": 30000, params: ["work/clock.png"], "bundleName": "top.huangjiangjun.mobile_officing", "moduleName": "entry" }, "考勤打卡");
        this.buildAppItem.bind(this)({ "id": 0, "type": 30000, params: ["work/report.png"], "bundleName": "top.huangjiangjun.mobile_officing", "moduleName": "entry" }, "汇报");
        this.buildAppItem.bind(this)({ "id": 0, "type": 30000, params: ["work/approve.png"], "bundleName": "top.huangjiangjun.mobile_officing", "moduleName": "entry" }, "OA审批");
        this.buildAppItem.bind(this)({ "id": 0, "type": 30000, params: ["work/card.png"], "bundleName": "top.huangjiangjun.mobile_officing", "moduleName": "entry" }, "补卡申请");
        this.buildAppItem.bind(this)({ "id": 0, "type": 30000, params: ["work/salary.png"], "bundleName": "top.huangjiangjun.mobile_officing", "moduleName": "entry" }, "工资单");
        this.buildAppItem.bind(this)({ "id": 0, "type": 30000, params: ["work/notice.png"], "bundleName": "top.huangjiangjun.mobile_officing", "moduleName": "entry" }, "公司公告");
        this.buildAppItem.bind(this)({ "id": 0, "type": 30000, params: ["work/rule.png"], "bundleName": "top.huangjiangjun.mobile_officing", "moduleName": "entry" }, "规章制度");
        Flex.pop();
    }
    // 应用管理
    buildAppManagement(parent = null) {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create();
            Column.debugLine("pages/Work/Work.ets(201:5)");
            Column.height(280);
            Column.width('94%');
            Column.backgroundColor(Color.White);
            Column.borderRadius(10);
            Column.offset({ y: -180 });
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create();
            Row.debugLine("pages/Work/Work.ets(202:7)");
            Row.padding({ left: 10, right: 10 });
            Row.justifyContent(FlexAlign.SpaceBetween);
            Row.height(60);
            Row.width('100%');
            Row.borderColor({ bottom: '#efefef' });
            Row.borderWidth({ bottom: 1 });
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create();
            Row.debugLine("pages/Work/Work.ets(203:9)");
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Image.create({ "id": 0, "type": 30000, params: ["work/menu.png"], "bundleName": "top.huangjiangjun.mobile_officing", "moduleName": "entry" });
            Image.debugLine("pages/Work/Work.ets(204:11)");
            Image.width(26);
            Image.height(26);
            if (!isInitialRender) {
                Image.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create("应用管理");
            Text.debugLine("pages/Work/Work.ets(207:11)");
            Text.margin({ left: 5 });
            Text.fontSize(20);
            Text.fontWeight(600);
            Text.fontColor('#101010');
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        Row.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create();
            Row.debugLine("pages/Work/Work.ets(214:9)");
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create("自定义");
            Text.debugLine("pages/Work/Work.ets(215:11)");
            Text.fontColor('#7f6666');
            Text.fontSize(16);
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Image.create({ "id": 0, "type": 30000, params: ["common/arraw_right.png"], "bundleName": "top.huangjiangjun.mobile_officing", "moduleName": "entry" });
            Image.debugLine("pages/Work/Work.ets(218:11)");
            Image.width(20);
            Image.height(20);
            if (!isInitialRender) {
                Image.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Row.pop();
        Row.pop();
        // this.buildAppContainer()
        this.buildAppContainer2.bind(this)();
        Column.pop();
    }
    // 我的申请
    buildApplyFor(parent = null) {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create();
            Column.debugLine("pages/Work/Work.ets(242:5)");
            Column.margin({
                top: -65,
                bottom: 15
            });
            Column.width('94%');
            Column.backgroundColor(Color.White);
            Column.borderRadius(10);
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create();
            Row.debugLine("pages/Work/Work.ets(243:7)");
            Row.padding({ left: 10, right: 10 });
            Row.justifyContent(FlexAlign.SpaceBetween);
            Row.height(60);
            Row.width('100%');
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create();
            Row.debugLine("pages/Work/Work.ets(244:9)");
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Image.create({ "id": 0, "type": 30000, params: ["work/badge.png"], "bundleName": "top.huangjiangjun.mobile_officing", "moduleName": "entry" });
            Image.debugLine("pages/Work/Work.ets(245:11)");
            Image.width(22);
            Image.height(22);
            if (!isInitialRender) {
                Image.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create("我的申请");
            Text.debugLine("pages/Work/Work.ets(248:11)");
            Text.margin({ left: 5 });
            Text.fontSize(20);
            Text.fontWeight(600);
            Text.fontColor('#101010');
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        Row.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create();
            Row.debugLine("pages/Work/Work.ets(255:9)");
            Row.onClick(() => {
                router.pushUrl({
                    url: "pages/Work/MyApplyFor/MyApplyFor"
                });
            });
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create("更多");
            Text.debugLine("pages/Work/Work.ets(256:11)");
            Text.fontColor('#7f6666');
            Text.fontSize(16);
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Image.create({ "id": 0, "type": 30000, params: ["common/arraw_right.png"], "bundleName": "top.huangjiangjun.mobile_officing", "moduleName": "entry" });
            Image.debugLine("pages/Work/Work.ets(259:11)");
            Image.width(20);
            Image.height(20);
            if (!isInitialRender) {
                Image.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Row.pop();
        Row.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            /**
             Row() {
             Row() {
             Text()
             .width(20)
             .height(20)
             .borderRadius(10)
             .backgroundColor('#4749a1')
             .margin({ top: 33 })
             }
             .alignItems(VerticalAlign.Top)
             .justifyContent(FlexAlign.Center)
             .height('100%')
             .width(40)
      
             Column() {
             Text("请假申请")
             .fontSize(20)
             .fontWeight(600)
             Text("2020/11/23 至 2020/11/24 共2天")
             Row() {
             Text('申请时间：2020-11-22 16:50')
             Text("待审批").fontColor('#ff935d')
             }
             .width('100%')
             .justifyContent(FlexAlign.SpaceBetween)
             .padding({ right: 20 })
             }
             .alignItems(HorizontalAlign.Start)
             .justifyContent(FlexAlign.SpaceEvenly)
             .layoutWeight(1)
             .height(130)
             }
             .width('100%')
             .height(160)
             .borderColor({ top: '#efefef' })
             .borderWidth({ top: 1 })
      
             Row() {
             Row() {
             Text()
             .width(20)
             .height(20)
             .borderRadius(10)
             .backgroundColor('#4749a1')
             .margin({ top: 33 })
             }
             .alignItems(VerticalAlign.Top)
             .justifyContent(FlexAlign.Center)
             .height('100%')
             .width(40)
      
             Column() {
             Text("请假申请")
             .fontSize(20)
             .fontWeight(600)
             Text("2020/11/23 至 2020/11/24 共2天")
             Row() {
             Text('申请时间：2020-11-22 16:50')
             Text("正在审批中")
             .fontColor('#53cbae')
             }
             .width('100%')
             .justifyContent(FlexAlign.SpaceBetween)
             .padding({ right: 20 })
             }
             .alignItems(HorizontalAlign.Start)
             .justifyContent(FlexAlign.SpaceEvenly)
             .layoutWeight(1)
             .height(130)
             }
             .width('100%')
             .height(160)
             .borderColor({ top: '#efefef' })
             .borderWidth({ top: 1 })
             **/
            ForEach.create();
            const forEachItemGenFunction = _item => {
                const process = _item;
                {
                    this.observeComponentCreation((elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        if (isInitialRender) {
                            ViewPU.create(new ApplyForItem(this, { process }, undefined, elmtId));
                        }
                        else {
                            this.updateStateVarsOfChildByElmtId(elmtId, {
                                process
                            });
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    });
                }
            };
            this.forEachUpdateFunction(elmtId, this.processList, forEachItemGenFunction);
            if (!isInitialRender) {
                /**
                 Row() {
                 Row() {
                 Text()
                 .width(20)
                 .height(20)
                 .borderRadius(10)
                 .backgroundColor('#4749a1')
                 .margin({ top: 33 })
                 }
                 .alignItems(VerticalAlign.Top)
                 .justifyContent(FlexAlign.Center)
                 .height('100%')
                 .width(40)
          
                 Column() {
                 Text("请假申请")
                 .fontSize(20)
                 .fontWeight(600)
                 Text("2020/11/23 至 2020/11/24 共2天")
                 Row() {
                 Text('申请时间：2020-11-22 16:50')
                 Text("待审批").fontColor('#ff935d')
                 }
                 .width('100%')
                 .justifyContent(FlexAlign.SpaceBetween)
                 .padding({ right: 20 })
                 }
                 .alignItems(HorizontalAlign.Start)
                 .justifyContent(FlexAlign.SpaceEvenly)
                 .layoutWeight(1)
                 .height(130)
                 }
                 .width('100%')
                 .height(160)
                 .borderColor({ top: '#efefef' })
                 .borderWidth({ top: 1 })
          
                 Row() {
                 Row() {
                 Text()
                 .width(20)
                 .height(20)
                 .borderRadius(10)
                 .backgroundColor('#4749a1')
                 .margin({ top: 33 })
                 }
                 .alignItems(VerticalAlign.Top)
                 .justifyContent(FlexAlign.Center)
                 .height('100%')
                 .width(40)
          
                 Column() {
                 Text("请假申请")
                 .fontSize(20)
                 .fontWeight(600)
                 Text("2020/11/23 至 2020/11/24 共2天")
                 Row() {
                 Text('申请时间：2020-11-22 16:50')
                 Text("正在审批中")
                 .fontColor('#53cbae')
                 }
                 .width('100%')
                 .justifyContent(FlexAlign.SpaceBetween)
                 .padding({ right: 20 })
                 }
                 .alignItems(HorizontalAlign.Start)
                 .justifyContent(FlexAlign.SpaceEvenly)
                 .layoutWeight(1)
                 .height(130)
                 }
                 .width('100%')
                 .height(160)
                 .borderColor({ top: '#efefef' })
                 .borderWidth({ top: 1 })
                 **/
                ForEach.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        /**
         Row() {
         Row() {
         Text()
         .width(20)
         .height(20)
         .borderRadius(10)
         .backgroundColor('#4749a1')
         .margin({ top: 33 })
         }
         .alignItems(VerticalAlign.Top)
         .justifyContent(FlexAlign.Center)
         .height('100%')
         .width(40)
  
         Column() {
         Text("请假申请")
         .fontSize(20)
         .fontWeight(600)
         Text("2020/11/23 至 2020/11/24 共2天")
         Row() {
         Text('申请时间：2020-11-22 16:50')
         Text("待审批").fontColor('#ff935d')
         }
         .width('100%')
         .justifyContent(FlexAlign.SpaceBetween)
         .padding({ right: 20 })
         }
         .alignItems(HorizontalAlign.Start)
         .justifyContent(FlexAlign.SpaceEvenly)
         .layoutWeight(1)
         .height(130)
         }
         .width('100%')
         .height(160)
         .borderColor({ top: '#efefef' })
         .borderWidth({ top: 1 })
  
         Row() {
         Row() {
         Text()
         .width(20)
         .height(20)
         .borderRadius(10)
         .backgroundColor('#4749a1')
         .margin({ top: 33 })
         }
         .alignItems(VerticalAlign.Top)
         .justifyContent(FlexAlign.Center)
         .height('100%')
         .width(40)
  
         Column() {
         Text("请假申请")
         .fontSize(20)
         .fontWeight(600)
         Text("2020/11/23 至 2020/11/24 共2天")
         Row() {
         Text('申请时间：2020-11-22 16:50')
         Text("正在审批中")
         .fontColor('#53cbae')
         }
         .width('100%')
         .justifyContent(FlexAlign.SpaceBetween)
         .padding({ right: 20 })
         }
         .alignItems(HorizontalAlign.Start)
         .justifyContent(FlexAlign.SpaceEvenly)
         .layoutWeight(1)
         .height(130)
         }
         .width('100%')
         .height(160)
         .borderColor({ top: '#efefef' })
         .borderWidth({ top: 1 })
         **/
        ForEach.pop();
        Column.pop();
    }
    initialRender() {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Stack.create({ alignContent: Alignment.TopStart });
            Stack.debugLine("pages/Work/Work.ets(364:5)");
            Stack.width('100%');
            Stack.height('100%');
            Stack.backgroundColor('#f5f5f5');
            if (!isInitialRender) {
                Stack.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        // 构建头部
        this.buildTop.bind(this)();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            List.create();
            List.debugLine("pages/Work/Work.ets(367:7)");
            List.alignListItem(ListItemAlign.Center);
            List.width('100%');
            List.height('100%');
            List.padding({
                top: 100
            });
            if (!isInitialRender) {
                List.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        // 提示信息
        this.buildTip.bind(this)();
        // 应用管理
        this.buildAppManagement.bind(this)();
        // 我的申请
        this.buildApplyFor.bind(this)();
        List.pop();
        Stack.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
//# sourceMappingURL=Work.js.map