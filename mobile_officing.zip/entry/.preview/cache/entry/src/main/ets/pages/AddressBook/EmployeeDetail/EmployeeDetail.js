import router from '@ohos:router';
import { NavBar } from '@bundle:top.huangjiangjun.mobile_officing/entry/ets/components/NavBar';
import call from '@ohos:telephony.call';
class EmployeeDetail extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1) {
        super(parent, __localStorage, elmtId);
        this.__employee = new ObservedPropertyObjectPU({}, this, "employee");
        this.setInitiallyProvidedValue(params);
    }
    setInitiallyProvidedValue(params) {
        if (params.employee !== undefined) {
            this.employee = params.employee;
        }
    }
    updateStateVars(params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__employee.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__employee.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    get employee() {
        return this.__employee.get();
    }
    set employee(newValue) {
        this.__employee.set(newValue);
    }
    aboutToAppear() {
        this.employee = router.getParams();
    }
    buildPart1(parent = null) {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create();
            Column.debugLine("pages/AddressBook/EmployeeDetail/EmployeeDetail.ets(16:5)");
            Column.padding({
                top: 20
            });
            Column.width('100%');
            Column.height(320);
            Column.borderRadius(10);
            Column.backgroundColor(Color.White);
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create(this.employee.name ? this.employee.name.substring(0, 1) : "");
            Text.debugLine("pages/AddressBook/EmployeeDetail/EmployeeDetail.ets(17:7)");
            Text.fontSize(30);
            Text.width(100);
            Text.height(100);
            Text.borderRadius(50);
            Text.backgroundColor('#6467d3');
            Text.fontColor(Color.White);
            Text.textAlign(TextAlign.Center);
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create(this.employee.name);
            Text.debugLine("pages/AddressBook/EmployeeDetail/EmployeeDetail.ets(25:7)");
            Text.fontSize(32);
            Text.fontColor('#101010');
            Text.fontWeight(FontWeight.Bold);
            Text.margin({
                top: 20
            });
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create(`${this.employee.department_name} / ${this.employee.position}`);
            Text.debugLine("pages/AddressBook/EmployeeDetail/EmployeeDetail.ets(32:7)");
            Text.fontSize(18);
            Text.fontColor('#101010');
            Text.margin({
                top: 20
            });
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create();
            Row.debugLine("pages/AddressBook/EmployeeDetail/EmployeeDetail.ets(39:7)");
            Row.margin({
                top: 20
            });
            Row.width('100%');
            Row.justifyContent(FlexAlign.SpaceAround);
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Button.createWithLabel("消息");
            Button.debugLine("pages/AddressBook/EmployeeDetail/EmployeeDetail.ets(40:9)");
            Button.fontSize(20);
            Button.width(150);
            Button.height(60);
            Button.fontColor(Color.White);
            Button.backgroundColor('#6467d3');
            Button.type(ButtonType.Normal);
            Button.borderRadius(8);
            if (!isInitialRender) {
                Button.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Button.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Button.createWithLabel("电话联系");
            Button.debugLine("pages/AddressBook/EmployeeDetail/EmployeeDetail.ets(49:9)");
            Button.fontSize(20);
            Button.width(150);
            Button.height(60);
            Button.fontColor(Color.White);
            Button.backgroundColor('#6467d3');
            Button.type(ButtonType.Normal);
            Button.borderRadius(8);
            Button.onClick(() => {
                call.makeCall(this.employee.phone, err => {
                    console.log(`makeCall callback: err->${JSON.stringify(err)}`);
                });
            });
            if (!isInitialRender) {
                Button.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Button.pop();
        Row.pop();
        Column.pop();
    }
    buildPart2(parent = null) {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create();
            Column.debugLine("pages/AddressBook/EmployeeDetail/EmployeeDetail.ets(79:5)");
            Column.padding(20);
            Column.width('100%');
            Column.borderRadius(10);
            Column.margin({
                top: 20
            });
            Column.backgroundColor(Color.White);
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create();
            Row.debugLine("pages/AddressBook/EmployeeDetail/EmployeeDetail.ets(80:7)");
            Row.width('100%');
            Row.justifyContent(FlexAlign.SpaceBetween);
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create("部门");
            Text.debugLine("pages/AddressBook/EmployeeDetail/EmployeeDetail.ets(81:9)");
            Text.fontSize(20);
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create(`${this.employee.department_name}\n${this.employee.team_name}`);
            Text.debugLine("pages/AddressBook/EmployeeDetail/EmployeeDetail.ets(83:9)");
            Text.fontSize(20);
            Text.fontColor('#4749a1');
            Text.textAlign(TextAlign.Center);
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        Row.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Divider.create();
            Divider.debugLine("pages/AddressBook/EmployeeDetail/EmployeeDetail.ets(91:7)");
            Divider.color('#ededed');
            Divider.height(1);
            Divider.width('100%');
            Divider.margin({
                top: 20,
                bottom: 20
            });
            if (!isInitialRender) {
                Divider.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create();
            Row.debugLine("pages/AddressBook/EmployeeDetail/EmployeeDetail.ets(100:7)");
            Row.width('100%');
            Row.justifyContent(FlexAlign.SpaceBetween);
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create("直属领导");
            Text.debugLine("pages/AddressBook/EmployeeDetail/EmployeeDetail.ets(101:9)");
            Text.fontSize(20);
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create(this.employee.direct_leader);
            Text.debugLine("pages/AddressBook/EmployeeDetail/EmployeeDetail.ets(103:9)");
            Text.fontSize(20);
            Text.fontColor('#4749a1');
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        Row.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Divider.create();
            Divider.debugLine("pages/AddressBook/EmployeeDetail/EmployeeDetail.ets(110:7)");
            Divider.color('#ededed');
            Divider.height(1);
            Divider.width('100%');
            Divider.margin({
                top: 20,
                bottom: 20
            });
            if (!isInitialRender) {
                Divider.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create();
            Row.debugLine("pages/AddressBook/EmployeeDetail/EmployeeDetail.ets(119:7)");
            Row.width('100%');
            Row.justifyContent(FlexAlign.SpaceBetween);
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create("入职时间");
            Text.debugLine("pages/AddressBook/EmployeeDetail/EmployeeDetail.ets(120:9)");
            Text.fontSize(20);
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create(this.employee.entry_time);
            Text.debugLine("pages/AddressBook/EmployeeDetail/EmployeeDetail.ets(122:9)");
            Text.fontSize(20);
            Text.fontColor('#4749a1');
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        Row.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Divider.create();
            Divider.debugLine("pages/AddressBook/EmployeeDetail/EmployeeDetail.ets(129:7)");
            Divider.color('#ededed');
            Divider.height(1);
            Divider.width('100%');
            Divider.margin({
                top: 20,
                bottom: 20
            });
            if (!isInitialRender) {
                Divider.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create();
            Row.debugLine("pages/AddressBook/EmployeeDetail/EmployeeDetail.ets(138:7)");
            Row.width('100%');
            Row.justifyContent(FlexAlign.SpaceBetween);
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create("备注");
            Text.debugLine("pages/AddressBook/EmployeeDetail/EmployeeDetail.ets(139:9)");
            Text.fontSize(20);
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create(this.employee.remark);
            Text.debugLine("pages/AddressBook/EmployeeDetail/EmployeeDetail.ets(141:9)");
            Text.fontSize(20);
            Text.fontColor('#4749a1');
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        Row.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Divider.create();
            Divider.debugLine("pages/AddressBook/EmployeeDetail/EmployeeDetail.ets(148:7)");
            Divider.color('#ededed');
            Divider.height(1);
            Divider.width('100%');
            Divider.margin({
                top: 20
            });
            if (!isInitialRender) {
                Divider.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Column.pop();
    }
    initialRender() {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create();
            Column.debugLine("pages/AddressBook/EmployeeDetail/EmployeeDetail.ets(166:5)");
            Column.width('100%');
            Column.height('100%');
            Column.backgroundColor('#f5f5f5');
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        {
            this.observeComponentCreation((elmtId, isInitialRender) => {
                ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                if (isInitialRender) {
                    ViewPU.create(new NavBar(this, { title: "个人信息" }, undefined, elmtId));
                }
                else {
                    this.updateStateVarsOfChildByElmtId(elmtId, {
                        title: "个人信息"
                    });
                }
                ViewStackProcessor.StopGetAccessRecording();
            });
        }
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            List.create();
            List.debugLine("pages/AddressBook/EmployeeDetail/EmployeeDetail.ets(169:7)");
            List.width('100%');
            List.layoutWeight(1);
            List.padding(15);
            if (!isInitialRender) {
                List.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        // 第一部分渲染
        this.buildPart1.bind(this)();
        // 第二部分渲染
        this.buildPart2.bind(this)();
        List.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
ViewStackProcessor.StartGetAccessRecordingFor(ViewStackProcessor.AllocateNewElmetIdForNextComponent());
loadDocument(new EmployeeDetail(undefined, {}));
ViewStackProcessor.StopGetAccessRecording();
//# sourceMappingURL=EmployeeDetail.js.map