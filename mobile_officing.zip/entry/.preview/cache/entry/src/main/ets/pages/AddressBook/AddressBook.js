var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { OrganizationComp } from '@bundle:top.huangjiangjun.mobile_officing/entry/ets/pages/AddressBook/components/OrganizationComp';
import { EmployeeComp } from '@bundle:top.huangjiangjun.mobile_officing/entry/ets/pages/AddressBook/components/EmployeeComp';
import { getEmployeeList, getDepartmentList } from '@bundle:top.huangjiangjun.mobile_officing/entry/ets/api/AddressBook';
import router from '@ohos:router';
let Organization = class Organization {
    constructor(icon, name, expand, employees) {
        this.icon = icon;
        this.name = name;
        this.expand = expand;
        this.employees = employees;
    }
};
Organization = __decorate([
    Observed
], Organization);
export { Organization };
export class AddressBook extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1) {
        super(parent, __localStorage, elmtId);
        this.__currentIndex = new ObservedPropertySimplePU(0, this, "currentIndex");
        this.__employeeList = new ObservedPropertyObjectPU([], this, "employeeList");
        this.__organizationList = new ObservedPropertyObjectPU([], this, "organizationList");
        this.setInitiallyProvidedValue(params);
    }
    setInitiallyProvidedValue(params) {
        if (params.currentIndex !== undefined) {
            this.currentIndex = params.currentIndex;
        }
        if (params.employeeList !== undefined) {
            this.employeeList = params.employeeList;
        }
        if (params.organizationList !== undefined) {
            this.organizationList = params.organizationList;
        }
    }
    updateStateVars(params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__currentIndex.purgeDependencyOnElmtId(rmElmtId);
        this.__employeeList.purgeDependencyOnElmtId(rmElmtId);
        this.__organizationList.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__currentIndex.aboutToBeDeleted();
        this.__employeeList.aboutToBeDeleted();
        this.__organizationList.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    get currentIndex() {
        return this.__currentIndex.get();
    }
    set currentIndex(newValue) {
        this.__currentIndex.set(newValue);
    }
    get employeeList() {
        return this.__employeeList.get();
    }
    set employeeList(newValue) {
        this.__employeeList.set(newValue);
    }
    get organizationList() {
        return this.__organizationList.get();
    }
    set organizationList(newValue) {
        this.__organizationList.set(newValue);
    }
    async getEmployeeListData() {
        const res = await getEmployeeList();
        this.employeeList = res.data;
    }
    async geDepartmentListData() {
        const res = await getDepartmentList();
        res.data.forEach((department) => {
            this.organizationList.push(new Organization({ "id": 0, "type": 30000, params: ["address-book/organization.png"], "bundleName": "top.huangjiangjun.mobile_officing", "moduleName": "entry" }, department.name, false, department.employees));
        });
    }
    aboutToAppear() {
        this.getEmployeeListData();
        this.geDepartmentListData();
    }
    buildTop(parent = null) {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create();
            Row.debugLine("pages/AddressBook/AddressBook.ets(48:5)");
            Row.justifyContent(FlexAlign.Center);
            Row.backgroundColor('#4749a1');
            Row.width('100%');
            Row.height(80);
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create("通讯录");
            Text.debugLine("pages/AddressBook/AddressBook.ets(49:7)");
            Text.fontColor(Color.White);
            Text.fontSize(26);
            Text.fontWeight(800);
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        Row.pop();
    }
    TabItemBuilder(index, name, parent = null) {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create();
            Column.debugLine("pages/AddressBook/AddressBook.ets(61:5)");
            Column.backgroundColor(Color.White);
            Column.padding({ bottom: 10 });
            Column.width('100%');
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create(name);
            Text.debugLine("pages/AddressBook/AddressBook.ets(62:7)");
            Text.fontColor('#4749a0');
            Text.fontSize(this.currentIndex === index ? 20 : 16);
            Text.fontWeight(this.currentIndex === index ? 800 : 300);
            Text.lineHeight(22);
            Text.margin({ top: 17, bottom: 10 });
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Divider.create();
            Divider.debugLine("pages/AddressBook/AddressBook.ets(68:7)");
            Divider.strokeWidth(5);
            Divider.color('#4749a0');
            Divider.width('50%');
            Divider.opacity(this.currentIndex === index ? 1 : 0);
            if (!isInitialRender) {
                Divider.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Column.pop();
    }
    // 联系人
    buildContactsItem(employee, parent = null) {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create();
            Row.debugLine("pages/AddressBook/AddressBook.ets(81:5)");
            Row.padding({ left: 20 });
            Row.width('100%');
            Row.height(80);
            Row.backgroundColor(Color.White);
            Row.borderRadius(10);
            Row.onClick(() => {
                router.pushUrl({
                    url: "pages/AddressBook/EmployeeDetail/EmployeeDetail",
                    params: employee
                });
            });
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Image.create(employee.avatar);
            Image.debugLine("pages/AddressBook/AddressBook.ets(82:7)");
            Image.width(56);
            Image.height(56);
            Image.borderRadius(28);
            if (!isInitialRender) {
                Image.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create(employee.name);
            Text.debugLine("pages/AddressBook/AddressBook.ets(86:7)");
            Text.fontSize(18);
            Text.fontWeight(FontWeight.Bold);
            Text.margin({ left: 10 });
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        Row.pop();
    }
    // 常用联系人列表
    buildContacts(parent = null) {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            List.create({ space: 10 });
            List.debugLine("pages/AddressBook/AddressBook.ets(106:5)");
            List.padding(15);
            List.height('100%');
            List.backgroundColor('#f7f7f7');
            if (!isInitialRender) {
                List.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            ForEach.create();
            const forEachItemGenFunction = _item => {
                const employee = _item;
                {
                    const isLazyCreate = true;
                    const itemCreation = (elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        ListItem.create(deepRenderFunction, isLazyCreate);
                        ListItem.debugLine("pages/AddressBook/AddressBook.ets(108:9)");
                        if (!isInitialRender) {
                            ListItem.pop();
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    };
                    const observedShallowRender = () => {
                        this.observeComponentCreation(itemCreation);
                        ListItem.pop();
                    };
                    const observedDeepRender = () => {
                        this.observeComponentCreation(itemCreation);
                        this.buildContactsItem.bind(this)(employee);
                        ListItem.pop();
                    };
                    const deepRenderFunction = (elmtId, isInitialRender) => {
                        itemCreation(elmtId, isInitialRender);
                        this.updateFuncByElmtId.set(elmtId, itemCreation);
                        this.buildContactsItem.bind(this)(employee);
                        ListItem.pop();
                    };
                    if (isLazyCreate) {
                        observedShallowRender();
                    }
                    else {
                        observedDeepRender();
                    }
                }
            };
            this.forEachUpdateFunction(elmtId, this.employeeList, forEachItemGenFunction);
            if (!isInitialRender) {
                ForEach.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        ForEach.pop();
        List.pop();
    }
    // 构建组织结构每一项
    buildOrganizationItem(organization, parent = null) {
        {
            this.observeComponentCreation((elmtId, isInitialRender) => {
                ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                if (isInitialRender) {
                    ViewPU.create(new OrganizationComp(this, { organization: organization }, undefined, elmtId));
                }
                else {
                    this.updateStateVarsOfChildByElmtId(elmtId, {
                        organization: organization
                    });
                }
                ViewStackProcessor.StopGetAccessRecording();
            });
        }
    }
    // 构建组织结构
    buildOrganization(parent = null) {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            List.create();
            List.debugLine("pages/AddressBook/AddressBook.ets(125:5)");
            List.sticky(StickyStyle.Header);
            List.width('100%');
            List.height('100%');
            if (!isInitialRender) {
                List.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            ForEach.create();
            const forEachItemGenFunction = _item => {
                const organization = _item;
                this.observeComponentCreation((elmtId, isInitialRender) => {
                    ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                    ListItemGroup.create({ header: this.buildOrganizationItem.bind(this, organization) });
                    ListItemGroup.debugLine("pages/AddressBook/AddressBook.ets(127:9)");
                    if (!isInitialRender) {
                        ListItemGroup.pop();
                    }
                    ViewStackProcessor.StopGetAccessRecording();
                });
                {
                    const isLazyCreate = true;
                    const itemCreation = (elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        ListItem.create(deepRenderFunction, isLazyCreate);
                        ListItem.debugLine("pages/AddressBook/AddressBook.ets(128:11)");
                        if (!isInitialRender) {
                            ListItem.pop();
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    };
                    const observedShallowRender = () => {
                        this.observeComponentCreation(itemCreation);
                        ListItem.pop();
                    };
                    const observedDeepRender = () => {
                        this.observeComponentCreation(itemCreation);
                        {
                            this.observeComponentCreation((elmtId, isInitialRender) => {
                                ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                                if (isInitialRender) {
                                    ViewPU.create(new EmployeeComp(this, { organization: organization }, undefined, elmtId));
                                }
                                else {
                                    this.updateStateVarsOfChildByElmtId(elmtId, {
                                        organization: organization
                                    });
                                }
                                ViewStackProcessor.StopGetAccessRecording();
                            });
                        }
                        ListItem.pop();
                    };
                    const deepRenderFunction = (elmtId, isInitialRender) => {
                        itemCreation(elmtId, isInitialRender);
                        this.updateFuncByElmtId.set(elmtId, itemCreation);
                        {
                            this.observeComponentCreation((elmtId, isInitialRender) => {
                                ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                                if (isInitialRender) {
                                    ViewPU.create(new EmployeeComp(this, { organization: organization }, undefined, elmtId));
                                }
                                else {
                                    this.updateStateVarsOfChildByElmtId(elmtId, {
                                        organization: organization
                                    });
                                }
                                ViewStackProcessor.StopGetAccessRecording();
                            });
                        }
                        ListItem.pop();
                    };
                    if (isLazyCreate) {
                        observedShallowRender();
                    }
                    else {
                        observedDeepRender();
                    }
                }
                ListItemGroup.pop();
            };
            this.forEachUpdateFunction(elmtId, this.organizationList, forEachItemGenFunction);
            if (!isInitialRender) {
                ForEach.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        ForEach.pop();
        List.pop();
    }
    buildTopTab(parent = null) {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Tabs.create({ barPosition: BarPosition.Start });
            Tabs.debugLine("pages/AddressBook/AddressBook.ets(140:5)");
            Tabs.backgroundColor(Color.White);
            Tabs.onChange((index) => {
                this.currentIndex = index;
            });
            Tabs.layoutWeight(1);
            Tabs.backgroundColor('#f7f7f7');
            if (!isInitialRender) {
                Tabs.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            TabContent.create(() => {
                this.buildContacts.bind(this)();
            });
            TabContent.tabBar({ builder: () => {
                    this.TabItemBuilder.call(this, 0, '常用联系人');
                } });
            TabContent.debugLine("pages/AddressBook/AddressBook.ets(141:7)");
            if (!isInitialRender) {
                TabContent.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        TabContent.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            TabContent.create(() => {
                this.buildOrganization.bind(this)();
            });
            TabContent.tabBar({ builder: () => {
                    this.TabItemBuilder.call(this, 1, '组织架构');
                } });
            TabContent.debugLine("pages/AddressBook/AddressBook.ets(145:7)");
            if (!isInitialRender) {
                TabContent.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        TabContent.pop();
        Tabs.pop();
    }
    initialRender() {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create();
            Column.debugLine("pages/AddressBook/AddressBook.ets(158:5)");
            Column.width('100%');
            Column.height('100%');
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        // 渲染顶部
        this.buildTop.bind(this)();
        // 渲染Tab
        this.buildTopTab.bind(this)();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
//# sourceMappingURL=AddressBook.js.map