var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import router from '@ohos:router';
import { applyForStatus, applyForStatusColor } from '@bundle:top.huangjiangjun.mobile_officing/entry/ets/utils/ApplyForUtil';
let MyProcess = class MyProcess {
    constructor() {
        this._id = '';
        this.approve_number = ''; // 审批编号
        this.department = ''; // 所在部门
        this.type_id = ''; // 类型 1：人事管理 2：行政事务 3：财务类 4：业务相关
        this.type = ''; // 请假类型
        this.reason = ''; // 请假事由/加班原因
        this.begin_date = ''; // 请假/加班开始日期
        this.end_date = ''; // 请假/加班结束日期
        this.begin_time = ''; // 请假/加班开始时间
        this.end_time = ''; // 请假/加班结束时间
        this.days = ''; // 请假/加班天数
        this.hours = ''; // 请假/加班小时
        this.initiator = ''; // 发起人
        this.department_leader = ''; // 部门领导
        this.personnel_department = ''; // 人事部
        this.cc_persons = ['']; // 抄送人
        this.approve_status = 0; // 审批状态 1：待审批 2、正在审批中 3、审批通过  4：拒绝
        this.status = 1; // 状态 1：启动 0：禁用
        this.created_at = '';
        this.updated_at = '';
    }
};
MyProcess = __decorate([
    Observed
], MyProcess);
export class ApplyForItem extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1) {
        super(parent, __localStorage, elmtId);
        this.__process = new SynchedPropertyNesedObjectPU(params.process, this, "process");
        this.setInitiallyProvidedValue(params);
    }
    setInitiallyProvidedValue(params) {
        this.__process.set(params.process);
    }
    updateStateVars(params) {
        this.__process.set(params.process);
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__process.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__process.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    get process() {
        return this.__process.get();
    }
    initialRender() {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create();
            Row.debugLine("components/ApplyForItem.ets(33:5)");
            Row.onClick(() => {
                router.pushUrl({
                    url: "pages/Work/ApplyForDetail/ApplyForDetail",
                    params: this.process
                });
            });
            Row.width('100%');
            Row.height(160);
            Row.borderColor({ top: '#efefef' });
            Row.borderWidth({ top: 1 });
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create();
            Row.debugLine("components/ApplyForItem.ets(34:7)");
            Row.alignItems(VerticalAlign.Top);
            Row.justifyContent(FlexAlign.Center);
            Row.height('100%');
            Row.width(40);
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create();
            Text.debugLine("components/ApplyForItem.ets(35:9)");
            Text.width(20);
            Text.height(20);
            Text.borderRadius(10);
            Text.backgroundColor('#4749a1');
            Text.margin({ top: 33 });
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        Row.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create();
            Column.debugLine("components/ApplyForItem.ets(47:7)");
            Column.alignItems(HorizontalAlign.Start);
            Column.justifyContent(FlexAlign.SpaceEvenly);
            Column.layoutWeight(1);
            Column.height(130);
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create(this.process.type);
            Text.debugLine("components/ApplyForItem.ets(48:9)");
            Text.fontSize(20);
            Text.fontWeight(600);
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create(`${this.process.begin_date.replace("-", "/")} 至 ${this.process.end_date.replace("-", "/")}  共${this.process.days}天`);
            Text.debugLine("components/ApplyForItem.ets(51:9)");
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create();
            Row.debugLine("components/ApplyForItem.ets(52:9)");
            Row.width('100%');
            Row.justifyContent(FlexAlign.SpaceBetween);
            Row.padding({ right: 20 });
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create(`申请时间：${this.process.created_at}`);
            Text.debugLine("components/ApplyForItem.ets(53:11)");
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create(applyForStatus(this.process.approve_status));
            Text.debugLine("components/ApplyForItem.ets(54:11)");
            Text.fontColor(applyForStatusColor(this.process.approve_status));
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        Row.pop();
        Column.pop();
        Row.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
//# sourceMappingURL=ApplyForItem.js.map