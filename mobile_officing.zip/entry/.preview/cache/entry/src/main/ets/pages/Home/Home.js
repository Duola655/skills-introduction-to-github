import { Work } from '@bundle:top.huangjiangjun.mobile_officing/entry/ets/pages/Work/Work';
import { Message } from '@bundle:top.huangjiangjun.mobile_officing/entry/ets/pages/Message/Message';
import { AddressBook } from '@bundle:top.huangjiangjun.mobile_officing/entry/ets/pages/AddressBook/AddressBook';
import { My } from '@bundle:top.huangjiangjun.mobile_officing/entry/ets/pages/My/My';
class Home extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1) {
        super(parent, __localStorage, elmtId);
        this.__currentIndex = new ObservedPropertySimplePU(0
        // tabBarItems的数据
        , this, "currentIndex");
        this.tabBarItems = [
            {
                text: { "id": 16777225, "type": 10003, params: [], "bundleName": "top.huangjiangjun.mobile_officing", "moduleName": "entry" },
                icon: { "id": 0, "type": 30000, params: ["tabBarItemImages/book.png"], "bundleName": "top.huangjiangjun.mobile_officing", "moduleName": "entry" },
                activeIcon: { "id": 0, "type": 30000, params: ["tabBarItemImages/book_active.png"], "bundleName": "top.huangjiangjun.mobile_officing", "moduleName": "entry" }
            },
            {
                text: { "id": 16777222, "type": 10003, params: [], "bundleName": "top.huangjiangjun.mobile_officing", "moduleName": "entry" },
                icon: { "id": 0, "type": 30000, params: ["tabBarItemImages/message.png"], "bundleName": "top.huangjiangjun.mobile_officing", "moduleName": "entry" },
                activeIcon: { "id": 0, "type": 30000, params: ["tabBarItemImages/message_active.png"], "bundleName": "top.huangjiangjun.mobile_officing", "moduleName": "entry" }
            },
            {
                text: { "id": 16777221, "type": 10003, params: [], "bundleName": "top.huangjiangjun.mobile_officing", "moduleName": "entry" },
                icon: { "id": 0, "type": 30000, params: ["tabBarItemImages/address_book.png"], "bundleName": "top.huangjiangjun.mobile_officing", "moduleName": "entry" },
                activeIcon: { "id": 0, "type": 30000, params: ["tabBarItemImages/address_book_active.png"], "bundleName": "top.huangjiangjun.mobile_officing", "moduleName": "entry" }
            },
            {
                text: { "id": 16777224, "type": 10003, params: [], "bundleName": "top.huangjiangjun.mobile_officing", "moduleName": "entry" },
                icon: { "id": 0, "type": 30000, params: ["tabBarItemImages/my.png"], "bundleName": "top.huangjiangjun.mobile_officing", "moduleName": "entry" },
                activeIcon: { "id": 0, "type": 30000, params: ["tabBarItemImages/my_active.png"], "bundleName": "top.huangjiangjun.mobile_officing", "moduleName": "entry" }
            }
        ];
        this.setInitiallyProvidedValue(params);
    }
    setInitiallyProvidedValue(params) {
        if (params.currentIndex !== undefined) {
            this.currentIndex = params.currentIndex;
        }
        if (params.tabBarItems !== undefined) {
            this.tabBarItems = params.tabBarItems;
        }
    }
    updateStateVars(params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__currentIndex.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__currentIndex.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    get currentIndex() {
        return this.__currentIndex.get();
    }
    set currentIndex(newValue) {
        this.__currentIndex.set(newValue);
    }
    TabItemBuilder(index, parent = null) {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create();
            Column.debugLine("pages/Home/Home.ets(36:5)");
            Column.width('100%');
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Image.create(this.currentIndex === index ? this.tabBarItems[index].activeIcon : this.tabBarItems[index].icon);
            Image.debugLine("pages/Home/Home.ets(37:7)");
            Image.width(24);
            Image.height(24);
            Image.margin({ bottom: 4 });
            Image.objectFit(ImageFit.Contain);
            if (!isInitialRender) {
                Image.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create(this.tabBarItems[index].text);
            Text.debugLine("pages/Home/Home.ets(42:7)");
            Text.fontColor(this.currentIndex === index ? '#4749a1' : '#9a9a9a');
            Text.fontSize(10);
            Text.fontWeight(500);
            Text.lineHeight(14);
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        Column.pop();
    }
    initialRender() {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create();
            Column.debugLine("pages/Home/Home.ets(51:5)");
            Column.width('100%');
            Column.height('100%');
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Tabs.create({ barPosition: BarPosition.End });
            Tabs.debugLine("pages/Home/Home.ets(52:7)");
            Tabs.onChange(index => {
                this.currentIndex = index;
            });
            if (!isInitialRender) {
                Tabs.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            ForEach.create();
            const forEachItemGenFunction = (_item, index) => {
                const item = _item;
                this.observeComponentCreation((elmtId, isInitialRender) => {
                    ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                    TabContent.create(() => {
                        this.observeComponentCreation((elmtId, isInitialRender) => {
                            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                            If.create();
                            if (this.currentIndex === 0) {
                                this.ifElseBranchUpdateFunction(0, () => {
                                    {
                                        this.observeComponentCreation((elmtId, isInitialRender) => {
                                            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                                            if (isInitialRender) {
                                                ViewPU.create(new Work(this, {}, undefined, elmtId));
                                            }
                                            else {
                                                this.updateStateVarsOfChildByElmtId(elmtId, {});
                                            }
                                            ViewStackProcessor.StopGetAccessRecording();
                                        });
                                    }
                                });
                            }
                            else if (this.currentIndex === 1) {
                                this.ifElseBranchUpdateFunction(1, () => {
                                    {
                                        this.observeComponentCreation((elmtId, isInitialRender) => {
                                            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                                            if (isInitialRender) {
                                                ViewPU.create(new Message(this, {}, undefined, elmtId));
                                            }
                                            else {
                                                this.updateStateVarsOfChildByElmtId(elmtId, {});
                                            }
                                            ViewStackProcessor.StopGetAccessRecording();
                                        });
                                    }
                                });
                            }
                            else if (this.currentIndex === 2) {
                                this.ifElseBranchUpdateFunction(2, () => {
                                    {
                                        this.observeComponentCreation((elmtId, isInitialRender) => {
                                            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                                            if (isInitialRender) {
                                                ViewPU.create(new AddressBook(this, {}, undefined, elmtId));
                                            }
                                            else {
                                                this.updateStateVarsOfChildByElmtId(elmtId, {});
                                            }
                                            ViewStackProcessor.StopGetAccessRecording();
                                        });
                                    }
                                });
                            }
                            else if (this.currentIndex === 3) {
                                this.ifElseBranchUpdateFunction(3, () => {
                                    {
                                        this.observeComponentCreation((elmtId, isInitialRender) => {
                                            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                                            if (isInitialRender) {
                                                ViewPU.create(new My(this, {}, undefined, elmtId));
                                            }
                                            else {
                                                this.updateStateVarsOfChildByElmtId(elmtId, {});
                                            }
                                            ViewStackProcessor.StopGetAccessRecording();
                                        });
                                    }
                                });
                            }
                            if (!isInitialRender) {
                                If.pop();
                            }
                            ViewStackProcessor.StopGetAccessRecording();
                        });
                        If.pop();
                    });
                    TabContent.tabBar({ builder: () => {
                            this.TabItemBuilder.call(this, index);
                        } });
                    TabContent.debugLine("pages/Home/Home.ets(55:11)");
                    if (!isInitialRender) {
                        // Tab的内容
                        TabContent.pop();
                    }
                    ViewStackProcessor.StopGetAccessRecording();
                });
                TabContent.pop();
            };
            this.forEachUpdateFunction(elmtId, this.tabBarItems, forEachItemGenFunction, undefined, true, false);
            if (!isInitialRender) {
                ForEach.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        ForEach.pop();
        Tabs.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
ViewStackProcessor.StartGetAccessRecordingFor(ViewStackProcessor.AllocateNewElmetIdForNextComponent());
loadDocument(new Home(undefined, {}));
ViewStackProcessor.StopGetAccessRecording();
//# sourceMappingURL=Home.js.map