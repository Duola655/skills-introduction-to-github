import { NavBar } from '@bundle:top.huangjiangjun.mobile_officing/entry/ets/components/NavBar';
class ClockIn extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1) {
        super(parent, __localStorage, elmtId);
        this.setInitiallyProvidedValue(params);
    }
    setInitiallyProvidedValue(params) {
    }
    updateStateVars(params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
    }
    aboutToBeDeleted() {
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    buildHeader(parent = null) {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create();
            Row.debugLine("pages/Work/ClockIn/ClockIn.ets(7:5)");
            Row.padding({
                left: 15
            });
            Row.backgroundColor(Color.White);
            Row.width('100%');
            Row.height(80);
            Row.borderRadius(8);
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Image.create({ "id": 0, "type": 30000, params: ["common/avatar2.png"], "bundleName": "top.huangjiangjun.mobile_officing", "moduleName": "entry" });
            Image.debugLine("pages/Work/ClockIn/ClockIn.ets(8:7)");
            Image.objectFit(ImageFit.Fill);
            Image.width(50);
            Image.height(50);
            Image.borderRadius(25);
            if (!isInitialRender) {
                Image.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create();
            Column.debugLine("pages/Work/ClockIn/ClockIn.ets(14:7)");
            Column.layoutWeight(1);
            Column.justifyContent(FlexAlign.SpaceBetween);
            Column.height('100%');
            Column.padding({
                left: 15,
                right: 15,
                top: 10,
                bottom: 10
            });
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create();
            Row.debugLine("pages/Work/ClockIn/ClockIn.ets(15:9)");
            Row.padding({ left: 20 });
            Row.width('100%');
            Row.justifyContent(FlexAlign.SpaceBetween);
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create("许夏天");
            Text.debugLine("pages/Work/ClockIn/ClockIn.ets(16:11)");
            Text.fontColor("#101010");
            Text.fontSize(20);
            Text.fontWeight(FontWeight.Bold);
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create("12月8日 星期四");
            Text.debugLine("pages/Work/ClockIn/ClockIn.ets(20:11)");
            Text.fontColor('#969896');
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        Row.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create();
            Row.debugLine("pages/Work/ClockIn/ClockIn.ets(27:9)");
            Row.padding({ left: 20 });
            Row.width('100%');
            Row.justifyContent(FlexAlign.SpaceBetween);
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create("技术部-成员");
            Text.debugLine("pages/Work/ClockIn/ClockIn.ets(28:11)");
            Text.fontColor('#969896');
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create("考勤规则");
            Text.debugLine("pages/Work/ClockIn/ClockIn.ets(30:11)");
            Text.padding({
                left: 5,
                right: 5,
                top: 2,
                bottom: 2
            });
            Text.fontColor('#5d67c2');
            Text.borderWidth(1);
            Text.borderColor('#5d67c2');
            Text.borderRadius(3);
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create("申请");
            Text.debugLine("pages/Work/ClockIn/ClockIn.ets(41:11)");
            Text.padding({
                left: 5,
                right: 5,
                top: 2,
                bottom: 2
            });
            Text.fontColor('#fff');
            Text.borderWidth(1);
            Text.borderColor('#ff5f35');
            Text.backgroundColor('#ff5f35');
            Text.borderRadius(3);
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        Row.pop();
        Column.pop();
        Row.pop();
    }
    buildContent(parent = null) {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create();
            Column.debugLine("pages/Work/ClockIn/ClockIn.ets(78:5)");
            Column.margin({
                top: 15
            });
            Column.backgroundColor(Color.White);
            Column.width('100%');
            Column.padding(15);
            Column.borderRadius(8);
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            // 上班时间
            Row.create();
            Row.debugLine("pages/Work/ClockIn/ClockIn.ets(80:7)");
            // 上班时间
            Row.width('100%');
            // 上班时间
            Row.height(40);
            if (!isInitialRender) {
                // 上班时间
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create();
            Text.debugLine("pages/Work/ClockIn/ClockIn.ets(81:9)");
            Text.backgroundColor('#4749a1');
            Text.width(10);
            Text.height(10);
            Text.borderRadius(5);
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create("上班时间 09:00");
            Text.debugLine("pages/Work/ClockIn/ClockIn.ets(86:9)");
            Text.margin({ left: 15 });
            Text.fontSize(14);
            Text.fontColor('#101010');
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        // 上班时间
        Row.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create();
            Row.debugLine("pages/Work/ClockIn/ClockIn.ets(96:7)");
            Row.justifyContent(FlexAlign.Center);
            Row.height(180);
            Row.width('100%');
            Row.margin({
                bottom: 20
            });
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create();
            Column.debugLine("pages/Work/ClockIn/ClockIn.ets(97:9)");
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create("上班打卡\n\n08:50");
            Text.debugLine("pages/Work/ClockIn/ClockIn.ets(98:11)");
            Text.fontColor(Color.White);
            Text.fontSize(20);
            Text.fontWeight(FontWeight.Bold);
            Text.textAlign(TextAlign.Center);
            Text.backgroundColor('#4749a1');
            Text.width(120);
            Text.height(120);
            Text.borderRadius(60);
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create();
            Row.debugLine("pages/Work/ClockIn/ClockIn.ets(109:11)");
            Row.margin({
                top: 20
            });
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Image.create({ "id": 0, "type": 30000, params: ["common/address.png"], "bundleName": "top.huangjiangjun.mobile_officing", "moduleName": "entry" });
            Image.debugLine("pages/Work/ClockIn/ClockIn.ets(110:13)");
            Image.width(20);
            Image.height(20);
            if (!isInitialRender) {
                Image.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create("华为深圳软件研发基地");
            Text.debugLine("pages/Work/ClockIn/ClockIn.ets(114:13)");
            Text.fontColor('#676767');
            Text.margin({
                left: 10
            });
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        Row.pop();
        Column.pop();
        Row.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            // 下班时间
            Row.create();
            Row.debugLine("pages/Work/ClockIn/ClockIn.ets(133:7)");
            // 下班时间
            Row.width('100%');
            // 下班时间
            Row.height(40);
            if (!isInitialRender) {
                // 下班时间
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create();
            Text.debugLine("pages/Work/ClockIn/ClockIn.ets(134:9)");
            Text.backgroundColor('#ffb867');
            Text.width(10);
            Text.height(10);
            Text.borderRadius(5);
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create("上班时间 18:00");
            Text.debugLine("pages/Work/ClockIn/ClockIn.ets(139:9)");
            Text.margin({ left: 15 });
            Text.fontSize(14);
            Text.fontColor('#101010');
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        // 下班时间
        Row.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create();
            Row.debugLine("pages/Work/ClockIn/ClockIn.ets(149:7)");
            Row.justifyContent(FlexAlign.Center);
            Row.height(180);
            Row.width('100%');
            Row.margin({
                bottom: 20
            });
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create();
            Column.debugLine("pages/Work/ClockIn/ClockIn.ets(150:9)");
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create("下班打卡\n\n18:30");
            Text.debugLine("pages/Work/ClockIn/ClockIn.ets(151:11)");
            Text.fontColor(Color.White);
            Text.fontSize(20);
            Text.fontWeight(FontWeight.Bold);
            Text.textAlign(TextAlign.Center);
            Text.backgroundColor('#4749a1');
            Text.width(120);
            Text.height(120);
            Text.borderRadius(60);
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create();
            Row.debugLine("pages/Work/ClockIn/ClockIn.ets(161:11)");
            Row.margin({
                top: 20
            });
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Image.create({ "id": 0, "type": 30000, params: ["common/address.png"], "bundleName": "top.huangjiangjun.mobile_officing", "moduleName": "entry" });
            Image.debugLine("pages/Work/ClockIn/ClockIn.ets(162:13)");
            Image.width(20);
            Image.height(20);
            if (!isInitialRender) {
                Image.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create("华为深圳软件研发基地");
            Text.debugLine("pages/Work/ClockIn/ClockIn.ets(166:13)");
            Text.fontColor('#676767');
            Text.margin({
                left: 10
            });
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        Row.pop();
        Column.pop();
        Row.pop();
        Column.pop();
    }
    initialRender() {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create();
            Column.debugLine("pages/Work/ClockIn/ClockIn.ets(194:5)");
            Column.width('100%');
            Column.height('100%');
            Column.backgroundColor('#f5f5f5');
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        {
            this.observeComponentCreation((elmtId, isInitialRender) => {
                ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                if (isInitialRender) {
                    ViewPU.create(new NavBar(this, { title: "考勤打卡" }, undefined, elmtId));
                }
                else {
                    this.updateStateVarsOfChildByElmtId(elmtId, {
                        title: "考勤打卡"
                    });
                }
                ViewStackProcessor.StopGetAccessRecording();
            });
        }
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create();
            Column.debugLine("pages/Work/ClockIn/ClockIn.ets(197:7)");
            Column.padding(15);
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        // 渲染头部
        this.buildHeader.bind(this)();
        // 渲染内容
        this.buildContent.bind(this)();
        Column.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
ViewStackProcessor.StartGetAccessRecordingFor(ViewStackProcessor.AllocateNewElmetIdForNextComponent());
loadDocument(new ClockIn(undefined, {}));
ViewStackProcessor.StopGetAccessRecording();
//# sourceMappingURL=ClockIn.js.map