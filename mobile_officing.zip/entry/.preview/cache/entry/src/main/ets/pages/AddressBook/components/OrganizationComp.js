export class OrganizationComp extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1) {
        super(parent, __localStorage, elmtId);
        this.__organization = new SynchedPropertyNesedObjectPU(params.organization, this, "organization");
        this.setInitiallyProvidedValue(params);
    }
    setInitiallyProvidedValue(params) {
        this.__organization.set(params.organization);
    }
    updateStateVars(params) {
        this.__organization.set(params.organization);
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__organization.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__organization.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    get organization() {
        return this.__organization.get();
    }
    initialRender() {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create();
            Row.debugLine("pages/AddressBook/components/OrganizationComp.ets(9:5)");
            Row.padding(20);
            Row.alignItems(VerticalAlign.Center);
            Row.justifyContent(FlexAlign.SpaceBetween);
            Row.width('100%');
            Row.height(80);
            Row.backgroundColor('#f7f7f7');
            Row.zIndex(1);
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create();
            Row.debugLine("pages/AddressBook/components/OrganizationComp.ets(10:7)");
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Image.create(this.organization.icon);
            Image.debugLine("pages/AddressBook/components/OrganizationComp.ets(11:9)");
            Image.size({ width: 50, height: 50 });
            if (!isInitialRender) {
                Image.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create(this.organization.name);
            Text.debugLine("pages/AddressBook/components/OrganizationComp.ets(13:9)");
            Text.fontSize(20);
            Text.fontWeight(FontWeight.Bold);
            Text.margin({ left: 10 });
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        Row.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Image.create(this.organization.expand ? { "id": 0, "type": 30000, params: ["common/arrow_top.png"], "bundleName": "top.huangjiangjun.mobile_officing", "moduleName": "entry" } : { "id": 0, "type": 30000, params: ["common/arraw_right.png"], "bundleName": "top.huangjiangjun.mobile_officing", "moduleName": "entry" });
            Image.debugLine("pages/AddressBook/components/OrganizationComp.ets(19:7)");
            Image.size({ width: this.organization.expand ? 25 : 30, height: this.organization.expand ? 25 : 30 });
            Image.onClick(() => {
                this.organization.expand = !this.organization.expand;
            });
            if (!isInitialRender) {
                Image.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Row.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
//# sourceMappingURL=OrganizationComp.js.map