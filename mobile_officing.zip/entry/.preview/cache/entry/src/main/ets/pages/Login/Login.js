import promptAction from '@ohos:promptAction';
import router from '@ohos:router';
import { login } from '@bundle:top.huangjiangjun.mobile_officing/entry/ets/api/User';
import PreferencesUtil from '@bundle:top.huangjiangjun.mobile_officing/entry/ets/utils/PreferencesUtil';
class Login extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1) {
        super(parent, __localStorage, elmtId);
        this.__loginname = new ObservedPropertySimplePU('17704051019', this, "loginname");
        this.__password = new ObservedPropertySimplePU('123456', this, "password");
        this.setInitiallyProvidedValue(params);
    }
    setInitiallyProvidedValue(params) {
        if (params.loginname !== undefined) {
            this.loginname = params.loginname;
        }
        if (params.password !== undefined) {
            this.password = params.password;
        }
    }
    updateStateVars(params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__loginname.purgeDependencyOnElmtId(rmElmtId);
        this.__password.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__loginname.aboutToBeDeleted();
        this.__password.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    get loginname() {
        return this.__loginname.get();
    }
    set loginname(newValue) {
        this.__loginname.set(newValue);
    }
    get password() {
        return this.__password.get();
    }
    set password(newValue) {
        this.__password.set(newValue);
    }
    async onLogin() {
        // 校验手机号和密码
        const loginNameRegex = /^1[3-9]\d{9}$/;
        if (!loginNameRegex.test(this.loginname)) {
            promptAction.showToast({
                message: '手机号不合法',
                duration: 500,
                bottom: 100
            });
            return;
        }
        const passwordRegex = /^\d{6,16}$/;
        if (!passwordRegex.test(this.password)) {
            promptAction.showToast({
                message: '密码要6-16位',
                duration: 500,
                bottom: 100
            });
            return;
        }
        const res = await login({
            loginname: this.loginname,
            password: this.password
        });
        // 提示
        promptAction.showToast({
            message: res.message,
            duration: 500,
            bottom: 100
        });
        if (res.code === 200) {
            // 存储token
            PreferencesUtil.saveToken(res.data.token);
            setTimeout(() => {
                router.replaceUrl({
                    url: 'pages/Home/Home'
                });
            }, 500);
        }
    }
    initialRender() {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create();
            Column.debugLine("pages/Login/Login.ets(59:5)");
            Column.width('100%');
            Column.height('100%');
            Column.backgroundColor('#f5f5f5');
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Image.create({ "id": 0, "type": 30000, params: ["login/login1.png"], "bundleName": "top.huangjiangjun.mobile_officing", "moduleName": "entry" });
            Image.debugLine("pages/Login/Login.ets(60:7)");
            Image.objectFit(ImageFit.Fill);
            Image.width('100%');
            Image.height(300);
            if (!isInitialRender) {
                Image.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create();
            Column.debugLine("pages/Login/Login.ets(65:7)");
            Column.backgroundColor(Color.White);
            Column.borderRadius(5);
            Column.width('94%');
            Column.height(350);
            Column.margin({
                top: -50
            });
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            // 账号输入框
            Row.create();
            Row.debugLine("pages/Login/Login.ets(67:9)");
            // 账号输入框
            Row.borderWidth(1);
            // 账号输入框
            Row.borderColor('#d5d5d5');
            // 账号输入框
            Row.height(50);
            // 账号输入框
            Row.width('90%');
            // 账号输入框
            Row.borderRadius(0);
            // 账号输入框
            Row.margin({
                top: 30
            });
            if (!isInitialRender) {
                // 账号输入框
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Image.create({ "id": 0, "type": 30000, params: ["login/phone.png"], "bundleName": "top.huangjiangjun.mobile_officing", "moduleName": "entry" });
            Image.debugLine("pages/Login/Login.ets(68:11)");
            Image.width(20);
            Image.height(30);
            Image.margin({ left: 10 });
            if (!isInitialRender) {
                Image.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            TextInput.create({
                placeholder: "请输入账号",
                text: this.loginname
            });
            TextInput.debugLine("pages/Login/Login.ets(72:11)");
            TextInput.height('100%');
            TextInput.layoutWeight(1);
            TextInput.borderRadius(0);
            TextInput.backgroundColor(Color.White);
            TextInput.onChange(value => {
                this.loginname = value;
            });
            if (!isInitialRender) {
                TextInput.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        // 账号输入框
        Row.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            // 密码输入框
            Row.create();
            Row.debugLine("pages/Login/Login.ets(94:9)");
            // 密码输入框
            Row.borderWidth(1);
            // 密码输入框
            Row.borderColor('#d5d5d5');
            // 密码输入框
            Row.height(50);
            // 密码输入框
            Row.width('90%');
            // 密码输入框
            Row.borderRadius(0);
            // 密码输入框
            Row.margin({
                top: 30
            });
            if (!isInitialRender) {
                // 密码输入框
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Image.create({ "id": 0, "type": 30000, params: ["login/password.png"], "bundleName": "top.huangjiangjun.mobile_officing", "moduleName": "entry" });
            Image.debugLine("pages/Login/Login.ets(95:11)");
            Image.width(20);
            Image.height(30);
            Image.margin({ left: 10 });
            if (!isInitialRender) {
                Image.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            TextInput.create({
                placeholder: "请输入密码",
                text: this.password
            });
            TextInput.debugLine("pages/Login/Login.ets(99:11)");
            TextInput.type(InputType.Password);
            TextInput.height('100%');
            TextInput.backgroundColor(Color.White);
            TextInput.layoutWeight(1);
            TextInput.borderRadius(0);
            TextInput.onChange(value => {
                this.password = value;
            });
            if (!isInitialRender) {
                TextInput.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        // 密码输入框
        Row.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            // 登录按钮
            Button.createWithLabel('登录');
            Button.debugLine("pages/Login/Login.ets(122:9)");
            // 登录按钮
            Button.backgroundColor('#4749a1');
            // 登录按钮
            Button.height(60);
            // 登录按钮
            Button.width('85%');
            // 登录按钮
            Button.margin({
                top: 30
            });
            // 登录按钮
            Button.onClick(() => {
                this.onLogin();
            });
            if (!isInitialRender) {
                // 登录按钮
                Button.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        // 登录按钮
        Button.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            // 隐私条款
            Row.create();
            Row.debugLine("pages/Login/Login.ets(134:9)");
            // 隐私条款
            Row.margin({
                top: 40
            });
            if (!isInitialRender) {
                // 隐私条款
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create("登录及代表同意");
            Text.debugLine("pages/Login/Login.ets(135:11)");
            Text.fontColor('#919191');
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create("《同意协议》");
            Text.debugLine("pages/Login/Login.ets(137:11)");
            Text.fontColor('#333333');
            Text.fontWeight(FontWeight.Bold);
            Text.onClick(() => {
                console.log('---点击了用户协议---');
            });
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create("和");
            Text.debugLine("pages/Login/Login.ets(143:11)");
            Text.fontColor('#919191');
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create("《隐私条款》");
            Text.debugLine("pages/Login/Login.ets(145:11)");
            Text.fontColor('#333333');
            Text.fontWeight(FontWeight.Bold);
            Text.onClick(() => {
                console.log('---点击了隐私条款---');
            });
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        // 隐私条款
        Row.pop();
        Column.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create('忘记密码');
            Text.debugLine("pages/Login/Login.ets(164:7)");
            Text.fontColor('#4749a1');
            Text.margin({
                top: 120
            });
            Text.onClick(() => {
            });
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
ViewStackProcessor.StartGetAccessRecordingFor(ViewStackProcessor.AllocateNewElmetIdForNextComponent());
loadDocument(new Login(undefined, {}));
ViewStackProcessor.StopGetAccessRecording();
//# sourceMappingURL=Login.js.map